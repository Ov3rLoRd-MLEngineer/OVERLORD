"""
organize_project.py - Organisateur de Dossier OverLord Pipeline
Scan le dossier PIPELINE PROJECT et le réorganise correctement.

Compile en .exe avec :
  python build_organizer.py
  → dist/OrganizeProject.exe  (double-clic = organisation instantanée)

Structure cible :
  PIPELINE PROJECT\
  ├── launcher.py
  ├── maestro.py
  ├── neural_orchestrator.py
  ├── agent_supervisor_v2.py
  ├── comfy_synesthesia_node.py
  ├── licence_server.py
  ├── llama_chat.py
  ├── learning_ui.py
  ├── build_exe.py
  ├── build_organizer.py
  ├── download_dependencies.bat
  ├── update_checkpoint.py
  ├── Combined_V35_API.json
  ├── Combined_V35_CANVAS.json
  ├── config.json
  ├── node_catalog.json
  ├── settings.json            (auto-généré)
  │
  ├── AGENTS\                  (tous les agents)
  ├── DOCS\                    (*.md, *.txt, *.pdf)
  ├── BACKUP\                  (copies de sécurité)
  ├── VRAC\                    (fichiers non classés)
  └── workspace\               (données runtime, créé automatiquement)
"""

import sys
import os
import shutil
import json
from pathlib import Path
from datetime import datetime

# ── Couleurs console Windows ──────────────────────────────────────────
try:
    import colorama
    colorama.init()
    C_GREEN  = "\033[92m"
    C_YELLOW = "\033[93m"
    C_RED    = "\033[91m"
    C_CYAN   = "\033[96m"
    C_BOLD   = "\033[1m"
    C_RESET  = "\033[0m"
except ImportError:
    C_GREEN = C_YELLOW = C_RED = C_CYAN = C_BOLD = C_RESET = ""

# ── Structure attendue ────────────────────────────────────────────────

# Fichiers à la racine (rester à la racine)
ROOT_FILES = {
    "launcher.py", "maestro.py", "neural_orchestrator.py",
    "agent_supervisor_v2.py", "comfy_synesthesia_node.py",
    "licence_server.py", "llama_chat.py", "learning_ui.py",
    "build_exe.py", "build_organizer.py", "organize_project.py",
    "download_dependencies.bat", "update_checkpoint.py",
    "Combined_V35_API.json", "Combined_V35_CANVAS.json",
    "config.json", "node_catalog.json", "settings.json",
    "MaestroProduction.spec", "learning_settings.json",
    "llama_chat_settings.json", "6.0.0",
}

# Fichiers à placer dans AGENTS\
AGENT_FILES = {
    "sourcing.py", "scenario.py", "storyboard.py", "postprod.py",
    "critic.py", "watchdog.py", "sav_agent.py", "sav_debug.py",
    "obs_agent.py", "capture.py", "comfy_memory.py",
    "checkpoint_manager.py", "agent_3d_modeler.py",
    "workflow_organizer.py", "ollama_bridge.py",
    "learning_agent.py", "legacy_agent.py", "memory_agent.py",
    "marketing_pub.py", "webmaster.py", "community_manager.py",
    "social_agent.py", "sys_agent.py", "remote_gpu.py",
    "gpu_scheduler.py", "ray_cluster.py", "roles_registry.py",
    "context_bus.py", "pipeline_constitution.py",
    "sourcing_multisensor.py", "multi_attention.py",
    "__init__.py",
}

# Extensions → dossier cible
EXT_TO_DIR = {
    ".md":   "DOCS",
    ".txt":  "DOCS",
    ".pdf":  "DOCS",
    ".docx": "DOCS",
    ".png":  "DOCS",   # screenshots/images projet
    ".spec": "BACKUP",
}

# Dossiers à créer
REQUIRED_DIRS = ["AGENTS", "DOCS", "BACKUP", "VRAC", "workspace"]


def print_banner():
    print(f"""
{C_BOLD}{C_CYAN}
  ██████╗ ██╗   ██╗███████╗██████╗ ██╗      ██████╗ ██████╗ ██████╗
  ██╔══██╗██║   ██║██╔════╝██╔══██╗██║     ██╔═══██╗██╔══██╗██╔══██╗
  ██║  ██║██║   ██║█████╗  ██████╔╝██║     ██║   ██║██████╔╝██║  ██║
  Organisateur de Projet - v1.10
{C_RESET}""")


def log_ok(msg):   print(f"  {C_GREEN}✓{C_RESET}  {msg}")
def log_mv(msg):   print(f"  {C_YELLOW}→{C_RESET}  {msg}")
def log_sk(msg):   print(f"  {C_CYAN}○{C_RESET}  {msg}")
def log_err(msg):  print(f"  {C_RED}✗{C_RESET}  {msg}")
def log_sec(msg):  print(f"\n{C_BOLD}{C_CYAN}━━━ {msg} ━━━{C_RESET}")


def find_project_root() -> Path:
    """Trouve la racine du projet PIPELINE PROJECT."""
    # Si lancé depuis l'intérieur du projet
    cwd = Path.cwd()
    if (cwd / "launcher.py").exists() or (cwd / "maestro.py").exists():
        return cwd
    # Si l'exe est à la racine du projet
    exe_dir = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).parent
    if (exe_dir / "launcher.py").exists():
        return exe_dir
    # Chercher dans les dossiers parents
    for parent in [cwd] + list(cwd.parents)[:3]:
        if (parent / "launcher.py").exists() and (parent / "maestro.py").exists():
            return parent
    return cwd


def scan_project(root: Path) -> dict:
    """Scanne le dossier et classifie chaque fichier."""
    report = {
        "root":       root,
        "at_root":    [],   # fichiers à la racine (bon endroit)
        "to_agents":  [],   # à déplacer vers AGENTS\
        "to_docs":    [],   # à déplacer vers DOCS\
        "to_backup":  [],   # à déplacer vers BACKUP\
        "to_vrac":    [],   # non classifiés
        "already_ok": [],   # déjà bien placés
        "unknown":    [],   # inconnus
    }

    # Scanner la racine uniquement (pas récursif pour les .py)
    for f in root.iterdir():
        if f.is_dir():
            continue
        name = f.name
        ext  = f.suffix.lower()

        # Déjà dans le bon dossier agents ?
        agents_dir = root / "AGENTS"
        if name in AGENT_FILES and (agents_dir / name).exists():
            report["already_ok"].append(f)
            continue

        if name in ROOT_FILES:
            report["at_root"].append(f)
        elif name in AGENT_FILES:
            report["to_agents"].append(f)
        elif ext in EXT_TO_DIR:
            target = EXT_TO_DIR[ext]
            if target == "DOCS":
                report["to_docs"].append(f)
            elif target == "BACKUP":
                report["to_backup"].append(f)
        elif ext == ".py" and name not in ROOT_FILES:
            # Python non reconnu → AGENTS par défaut
            report["to_agents"].append(f)
        elif name.startswith(".") or name == "__pycache__":
            pass   # ignorer
        else:
            report["unknown"].append(f)

    return report


def create_dirs(root: Path) -> list[Path]:
    """Crée les dossiers requis s'ils n'existent pas."""
    created = []
    for d in REQUIRED_DIRS:
        p = root / d
        if not p.exists():
            p.mkdir(parents=True)
            created.append(p)
    return created


def backup_existing_agents(root: Path):
    """Sauvegarde l'état actuel du dossier AGENTS avant réorganisation."""
    agents_dir = root / "AGENTS"
    if not agents_dir.exists():
        return
    backup_dir = root / "BACKUP" / f"agents_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    backup_dir.mkdir(parents=True, exist_ok=True)
    for f in agents_dir.glob("*.py"):
        shutil.copy2(str(f), str(backup_dir / f.name))
    log_ok(f"Backup agents → BACKUP/{backup_dir.name}/")


def move_files(files: list[Path], dest_dir: Path,
               dry_run: bool = False) -> tuple[int, int]:
    """Déplace une liste de fichiers vers un dossier."""
    ok = 0; skip = 0
    for f in files:
        dest = dest_dir / f.name
        if dest.exists():
            log_sk(f"Déjà présent : {f.name}")
            skip += 1
            continue
        if not dry_run:
            shutil.move(str(f), str(dest))
        log_mv(f"{f.name} → {dest_dir.name}\\")
        ok += 1
    return ok, skip


def create_agents_init(agents_dir: Path):
    """Cree/met a jour le __init__.py dans AGENTS"""
    init = agents_dir / "__init__.py"
    content = '# OverLord Pipeline - Package Agents v1.10\n'  
    init.write_text(content, encoding="utf-8")


def write_project_map(root: Path):
    """Génère PROJECT_MAP.md - carte du projet après organisation."""
    py_files = list((root / "AGENTS").glob("*.py")) if (root/"AGENTS").exists() else []
    root_py  = [f for f in root.glob("*.py") if f.name in ROOT_FILES]
    docs     = list((root / "DOCS").glob("*")) if (root/"DOCS").exists() else []

    lines = [
        "# PIPELINE PROJECT - Carte du projet",
        f"*Généré le {datetime.now().strftime('%d/%m/%Y %H:%M')} par OrganizeProject.exe*",
        "",
        "## Racine",
        *[f"- `{f.name}`" for f in sorted(root_py)],
        "",
        f"## AGENTS\\ ({len(py_files)} agents)",
        *[f"- `{f.name}`" for f in sorted(py_files)],
        "",
        f"## DOCS\\ ({len(docs)} fichiers)",
        *[f"- `{f.name}`" for f in sorted(docs)],
        "",
        "## workspace\\ (créé au runtime)",
        "- `context_bus/` - Context Window partagée",
        "- `checkpoints/` - Sauvegardes pipeline",
        "- `learning/` - Mémoire agent apprenant",
        "- `archive/` - Images générées",
        "- `proposals/` - Propositions Legacy Agent",
        "- `feedback/` - Données RLHF",
        "- `3d_output/` - Modèles 3D",
        "- `memory/` - Agent Mémoire",
        "",
        "---",
        "*OverLord Pipeline v1.10 - Architecture Neuronale*",
    ]
    (root / "DOCS" / "PROJECT_MAP.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )


def organize(root: Path, dry_run: bool = False) -> dict:
    """Organisation complète du projet."""
    print_banner()
    print(f"  Dossier cible : {C_BOLD}{root}{C_RESET}")
    print(f"  Mode          : {'SIMULATION (dry-run)' if dry_run else 'RÉEL'}\n")

    log_sec("SCAN")
    report = scan_project(root)
    total  = (len(report["at_root"]) + len(report["to_agents"]) +
               len(report["to_docs"]) + len(report["to_backup"]) +
               len(report["unknown"]))
    print(f"  {total} fichiers analysés\n")
    print(f"  À la racine (OK)  : {len(report['at_root'])}")
    print(f"  → AGENTS          : {len(report['to_agents'])}")
    print(f"  → DOCS            : {len(report['to_docs'])}")
    print(f"  → BACKUP          : {len(report['to_backup'])}")
    print(f"  → VRAC            : {len(report['unknown'])}")

    log_sec("CRÉATION DES DOSSIERS")
    created = create_dirs(root)
    if created:
        for d in created:
            log_ok(f"Créé : {d.name}\\")
    else:
        log_sk("Tous les dossiers existent déjà")

    log_sec("BACKUP")
    if not dry_run:
        backup_existing_agents(root)

    log_sec("DÉPLACEMENT AGENTS")
    agents_dir = root / "AGENTS"
    ok_a, sk_a = move_files(report["to_agents"], agents_dir, dry_run)
    if not dry_run:
        create_agents_init(agents_dir)

    log_sec("DÉPLACEMENT DOCS")
    docs_dir = root / "DOCS"
    ok_d, sk_d = move_files(report["to_docs"], docs_dir, dry_run)

    log_sec("DÉPLACEMENT BACKUP")
    bk_dir = root / "BACKUP"
    ok_b, sk_b = move_files(report["to_backup"], bk_dir, dry_run)

    if report["unknown"]:
        log_sec("FICHIERS NON CLASSÉS → VRAC")
        vrac_dir = root / "VRAC"
        ok_v, sk_v = move_files(report["unknown"], vrac_dir, dry_run)
    else:
        ok_v = sk_v = 0

    if not dry_run:
        write_project_map(root)
        log_ok("PROJECT_MAP.md généré dans DOCS\\")

    # Résumé
    total_moved = ok_a + ok_d + ok_b + ok_v
    log_sec("RÉSUMÉ")
    print(f"  {C_GREEN}✓{C_RESET} {total_moved} fichier(s) déplacé(s)")
    print(f"  {C_CYAN}○{C_RESET} {sk_a+sk_d+sk_b+sk_v} fichier(s) déjà en place")
    if dry_run:
        print(f"\n  {C_YELLOW}Mode simulation - rien n'a été modifié.{C_RESET}")
        print(f"  Lance sans --dry-run pour appliquer.")

    return {
        "moved":  total_moved,
        "skipped": sk_a+sk_d+sk_b+sk_v,
        "root":   str(root),
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(
        description="OverLord - Organisateur de projet"
    )
    parser.add_argument(
        "--path", type=str, default=None,
        help="Chemin du dossier PIPELINE PROJECT (auto-détecté si absent)"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Simulation sans modification réelle"
    )
    args = parser.parse_args()

    root = Path(args.path) if args.path else find_project_root()

    if not root.exists():
        log_err(f"Dossier introuvable : {root}")
        sys.exit(1)

    result = organize(root, dry_run=args.dry_run)

    print(f"\n  {C_BOLD}Organisation terminée !{C_RESET}")
    print(f"  Dossier : {result['root']}")

    # Pause si lancé en double-clic (pas de terminal permanent)
    if getattr(sys, "frozen", False):
        input("\n  Appuie sur Entrée pour fermer...")


if __name__ == "__main__":
    main()
