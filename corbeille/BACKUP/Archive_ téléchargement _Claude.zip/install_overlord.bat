@echo off
chcp 65001 >nul
title OverLord Pipeline - Installateur v1.30

echo ============================================================
echo    OverLord Pipeline v1.30 - Installateur
echo ============================================================
echo(

:: Detecter Python (python, py ou python3 selon installation Windows)
set PYTHON_CMD=

python --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python
    goto :PYTHON_FOUND
)

py --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=py
    goto :PYTHON_FOUND
)

python3 --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON_CMD=python3
    goto :PYTHON_FOUND
)

echo [ERREUR] Python introuvable dans le PATH.
echo(
echo Solutions :
echo   1. Telecharge Python 3.10+ sur https://python.org
echo   2. Coche "Add Python to PATH" pendant l'installation
echo   3. Relance ce fichier apres installation
echo(
pause
exit /b 1

:PYTHON_FOUND
for /f "tokens=2" %%v in ('%PYTHON_CMD% --version 2^>^&1') do set PY_VER=%%v
echo [OK] Python %PY_VER% detecte (commande : %PYTHON_CMD%)

:: Verifier version minimale 3.10
%PYTHON_CMD% -c "import sys; exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Python %PY_VER% trop ancien. Version 3.10 minimum requise.
    echo Telecharge Python 3.10+ sur https://python.org
    pause
    exit /b 1
)

:: Choisir le disque cible
echo(
echo Sur quel disque installer OverLord ?
echo   D = SSD 1To Pipeline (recommande)
echo   C = Disque systeme
echo(
set DRIVE_LETTER=D
set /p DRIVE_LETTER=Lettre du disque sans les deux points [D] : 
if "%DRIVE_LETTER%"=="" set DRIVE_LETTER=D

:: Supprimer le : si l'utilisateur l'a tape
set DRIVE_LETTER=%DRIVE_LETTER::=%

set TARGET_DRIVE=%DRIVE_LETTER%:

:: Verifier que le disque existe
if not exist "%TARGET_DRIVE%\" (
    echo(
    echo [ERREUR] Disque %TARGET_DRIVE% inaccessible.
    echo Branche le disque et relance l'installateur.
    pause
    exit /b 1
)

echo [OK] Disque %TARGET_DRIVE% detecte.
echo(
echo Installation vers %TARGET_DRIVE%\OVERLORD ...
echo(

:: Lancer l'installation Python
%PYTHON_CMD% install_overlord.py --drive %DRIVE_LETTER%

if errorlevel 1 (
    echo(
    echo [ERREUR] Installation incomplete. Consulte install_log.txt
    pause
    exit /b 1
)

echo(
echo ============================================================
echo    Installation terminee !
echo    Lance : %TARGET_DRIVE%\OVERLORD\START_OVERLORD.bat
echo ============================================================
echo(
pause
