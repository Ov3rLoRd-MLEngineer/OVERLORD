"""
agent_supervisor.py — Usine à Animés
Pipeline d'industrialisation ComfyUI
"""

import requests
import json
import time
import random
import logging
import hashlib
import shutil
from pathlib import Path
from datetime import datetime

# ============================================================
# CONFIGURATION
# ============================================================
COMFY_URL       = "http://127.0.0.1:8188"
WORKFLOW_FILE   = "Combined_V35_API.json"

# Dossier de travail (Black Box)
WORKSPACE       = Path("workspace")
LOGS_DIR        = WORKSPACE / "logs"
ARCHIVE_DIR     = WORKSPACE / "archive"
FAILED_FILE     = WORKSPACE / "failed_jobs.json"
CONFIG_FILE     = "config.json"           # fichier de batch optionnel

# IDs — Workflow Advanced
ADV_LORA_ID     = "62"
ADV_SEED_ID     = "112"
ADV_DIFF_ID     = "68"
ADV_POS_87      = "87"
ADV_POS_99      = "99"
ADV_NEG_ID      = "111"
ADV_WIDTH_ID    = "75"
ADV_HEIGHT_ID   = "77"

# IDs — Workflow Detailer (+300)
DET_LORA_ID     = "303"
DET_SEED_ID     = "382"
DET_POS_ID      = "301"
DET_NEG_ID      = "380"

# Valeurs par défaut
DEFAULT_POSITIVE = "masterpiece, best quality, amazing quality, absurdres, 1girl, solo, looking at viewer,"
DEFAULT_NEGATIVE = "bad quality, worst quality, worst detail, sketch, bad hands, bad anatomy, deformed, artist name, watermark, signature, patreon, twitter username"

# Paramètres qualité loopback
MAX_RETRIES     = 3      # tentatives max par job avant abandon
RETRY_DELAY     = 5      # secondes entre deux tentatives

# ============================================================
# INITIALISATION DU WORKSPACE
# ============================================================
def init_workspace():
    """Crée la structure de dossiers si elle n'existe pas."""
    for d in [WORKSPACE, LOGS_DIR, ARCHIVE_DIR]:
        d.mkdir(parents=True, exist_ok=True)
    if not FAILED_FILE.exists():
        FAILED_FILE.write_text("[]", encoding="utf-8")

def get_logger(run_id: str) -> logging.Logger:
    """Retourne un logger dédié à ce run, écrivant dans logs/."""
    logger = logging.getLogger(run_id)
    if logger.handlers:
        return logger
    logger.setLevel(logging.DEBUG)

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S")

    # Console
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # Fichier
    log_path = LOGS_DIR / f"{run_id}.log"
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    return logger


# ============================================================
# UTILITAIRES
# ============================================================
def job_hash(job: dict) -> str:
    """Hash court pour identifier un job de façon unique."""
    key = json.dumps(job, sort_keys=True)
    return hashlib.md5(key.encode()).hexdigest()[:8]

def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def save_failed_job(job: dict, reason: str):
    """Ajoute un job échoué dans failed_jobs.json."""
    try:
        failed = json.loads(FAILED_FILE.read_text(encoding="utf-8"))
    except Exception:
        failed = []
    failed.append({
        "timestamp": timestamp(),
        "reason":    reason,
        "job":       job
    })
    FAILED_FILE.write_text(
        json.dumps(failed, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

def load_config(path: str = CONFIG_FILE) -> list:
    """
    Charge une liste de jobs depuis config.json.
    Format attendu :
    [
      {"lora": "lora_A.safetensors", "strength": 0.8, "width": 896, "height": 1152},
      {"lora": "lora_B.safetensors", "strength": 1.0, "seed": 42},
      ...
    ]
    """
    cfg_path = Path(path)
    if not cfg_path.exists():
        raise FileNotFoundError(f"Fichier config introuvable : {path}")
    with open(cfg_path, encoding="utf-8") as f:
        jobs = json.load(f)
    if not isinstance(jobs, list):
        raise ValueError("config.json doit contenir une liste de jobs.")
    return jobs

def archive_job(job: dict, prompt_id: str, seed: int, logger: logging.Logger):
    """
    Crée un sous-dossier daté dans archive/ et y sauvegarde
    les paramètres du job pour traçabilité complète.
    """
    ts    = timestamp()
    jhash = job_hash(job)
    lora  = Path(job.get("lora", "no_lora")).stem
    folder_name = f"{ts}_{lora}_{jhash}"
    job_dir = ARCHIVE_DIR / folder_name
    job_dir.mkdir(parents=True, exist_ok=True)

    meta = {
        "timestamp":  ts,
        "prompt_id":  prompt_id,
        "seed":       seed,
        "job_hash":   jhash,
        "parameters": job
    }
    (job_dir / "meta.json").write_text(
        json.dumps(meta, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )
    logger.debug(f"Job archivé dans {job_dir}")
    return job_dir


# ============================================================
# CONSTRUCTION DU WORKFLOW
# ============================================================
def get_modified_workflow(
    strength      = 1.0,
    lora_name     = "",
    det_lora_name = "",
    positive_prompt = None,
    negative_prompt = None,
    width         = 1024,
    height        = 1536,
    seed          = None,
    det_seed      = None,
) -> tuple:
    """Charge Combined_V35_API.json et applique les paramètres du job."""

    with open(WORKFLOW_FILE, "r", encoding="utf-8") as f:
        wf = json.load(f)

    pos = positive_prompt or DEFAULT_POSITIVE
    neg = negative_prompt or DEFAULT_NEGATIVE

    if seed is None or seed < 0:
        seed = random.randint(1, 999_999_999_999)
    if det_seed is None or det_seed < 0:
        det_seed = seed

    # --- Advanced ---
    wf[ADV_SEED_ID]["inputs"]["seed"]     = seed
    wf[ADV_DIFF_ID]["inputs"]["strength"] = strength
    wf[ADV_WIDTH_ID]["inputs"]["value"]   = width
    wf[ADV_HEIGHT_ID]["inputs"]["value"]  = height
    wf[ADV_POS_87]["inputs"]["string_b"]  = pos
    wf[ADV_POS_99]["inputs"]["string_a"]  = pos
    wf[ADV_NEG_ID]["inputs"]["text"]      = neg

    if lora_name and lora_name.strip():
        wf[ADV_LORA_ID]["inputs"]["loras"] = {
            "__value__": [{"lora": lora_name, "strength": 1.0, "enabled": True}]
        }
    else:
        wf[ADV_LORA_ID]["inputs"]["loras"] = {"__value__": []}
    wf[ADV_LORA_ID]["inputs"]["text"] = ""

    # --- Detailer ---
    wf[DET_SEED_ID]["inputs"]["seed"]     = det_seed
    wf[DET_POS_ID]["inputs"]["text"]      = pos
    wf[DET_NEG_ID]["inputs"]["text"]      = neg

    if det_lora_name and det_lora_name.strip():
        wf[DET_LORA_ID]["inputs"]["loras"] = {
            "__value__": [{"lora": det_lora_name, "strength": 1.0, "enabled": True}]
        }
    else:
        wf[DET_LORA_ID]["inputs"]["loras"] = {"__value__": []}
    wf[DET_LORA_ID]["inputs"]["text"] = ""

    return wf, seed, det_seed


# ============================================================
# COMMUNICATION COMFYUI
# ============================================================
def send_to_comfy(wf: dict, logger: logging.Logger) -> str | None:
    """Envoie le workflow et retourne le prompt_id ou None."""
    try:
        resp = requests.post(
            f"{COMFY_URL}/prompt",
            json={"prompt": wf},
            timeout=30
        )
        if resp.status_code == 200:
            pid = resp.json().get("prompt_id")
            logger.info(f"Prompt envoyé → prompt_id={pid}")
            return pid
        else:
            logger.error(f"HTTP {resp.status_code}: {resp.text[:300]}")
            return None
    except requests.exceptions.ConnectionError:
        logger.error("Connexion refusée — ComfyUI est-il démarré ?")
        return None
    except requests.exceptions.Timeout:
        logger.error("Timeout lors de l'envoi du prompt.")
        return None
    except Exception as e:
        logger.error(f"Erreur inattendue lors de l'envoi : {e}")
        return None


def wait_for_completion(prompt_id: str, logger: logging.Logger,
                        timeout: int = 600) -> tuple:
    """
    Attend la fin d'exécution. Retourne (success: bool, outputs: dict).
    outputs contient les images produites pour le contrôle qualité.
    """
    logger.info(f"Attente de completion (timeout={timeout}s)...")
    start = time.time()

    while time.time() - start < timeout:
        try:
            resp = requests.get(
                f"{COMFY_URL}/history/{prompt_id}",
                timeout=10
            )
            if resp.status_code == 200:
                history = resp.json()
                if prompt_id in history:
                    entry  = history[prompt_id]
                    status = entry.get("status", {})

                    if status.get("completed"):
                        elapsed = time.time() - start
                        logger.info(f"Terminé en {elapsed:.1f}s")
                        outputs = entry.get("outputs", {})
                        return True, outputs

                    if status.get("status_str") == "error":
                        messages = status.get("messages", [])
                        logger.error(f"Erreur ComfyUI: {messages}")
                        return False, {}

        except requests.exceptions.Timeout:
            logger.warning("Timeout polling /history, nouvelle tentative...")
        except Exception as e:
            logger.warning(f"Erreur polling: {e}")

        time.sleep(3)

    logger.error(f"Timeout global atteint ({timeout}s).")
    return False, {}


def interrupt_comfy(logger: logging.Logger):
    try:
        requests.post(f"{COMFY_URL}/interrupt", timeout=5)
        logger.info("Interruption envoyée.")
    except Exception as e:
        logger.warning(f"Erreur interruption: {e}")


# ============================================================
# CONTRÔLE QUALITÉ — LOOPBACK
# ============================================================
def quality_check(outputs: dict, logger: logging.Logger) -> bool:
    """
    Contrôle qualité simple basé sur les outputs ComfyUI.

    Stratégie actuelle (sans dépendance externe) :
      - Vérifie qu'au moins une image a été produite par le nœud Image Saver (334)
      - Vérifie que le fichier image existe côté ComfyUI (via /view)

    Extension possible : appeler un nœud ComfyUI dédié (ex: ImageSharpness)
    et lire sa valeur dans outputs pour décider de relancer.

    Retourne True si le job est validé, False si relance nécessaire.
    """
    # Chercher les outputs du nœud Image Saver Detailer (334)
    saver_output = outputs.get("334", {})
    images = saver_output.get("images", [])

    if not images:
        logger.warning("Contrôle qualité : aucune image produite par le nœud 334.")
        return False

    # Vérifier que l'image est accessible sur le serveur ComfyUI
    img = images[0]
    filename  = img.get("filename", "")
    subfolder = img.get("subfolder", "")
    img_type  = img.get("type", "output")

    if not filename:
        logger.warning("Contrôle qualité : nom de fichier vide dans les outputs.")
        return False

    try:
        check_url = (
            f"{COMFY_URL}/view"
            f"?filename={filename}&subfolder={subfolder}&type={img_type}"
        )
        r = requests.head(check_url, timeout=10)
        if r.status_code == 200:
            logger.info(f"Contrôle qualité OK — image validée : {filename}")
            return True
        else:
            logger.warning(
                f"Contrôle qualité ÉCHEC — fichier inaccessible "
                f"(HTTP {r.status_code}): {filename}"
            )
            return False
    except Exception as e:
        logger.warning(f"Contrôle qualité : impossible de vérifier l'image : {e}")
        # En cas d'erreur réseau on valide par défaut pour ne pas boucler
        return True


# ============================================================
# EXÉCUTION D'UN JOB UNIQUE (avec retry)
# ============================================================
def run_job(job: dict, logger: logging.Logger) -> bool:
    """
    Exécute un job avec retry automatique et contrôle qualité.

    Un job est un dict avec les clés optionnelles :
        lora, det_lora, strength, positive, negative,
        width, height, seed, det_seed, max_retries, timeout
    """
    max_retries = job.get("max_retries", MAX_RETRIES)
    timeout     = job.get("timeout", 600)
    jhash       = job_hash(job)

    logger.info(
        f"[{jhash}] Job démarré — "
        f"lora={job.get('lora','') or 'aucun'} | "
        f"strength={job.get('strength', 1.0)} | "
        f"{job.get('width', 1024)}x{job.get('height', 1536)}"
    )

    for attempt in range(1, max_retries + 1):
        logger.info(f"[{jhash}] Tentative {attempt}/{max_retries}")

        # 1. Construire le workflow
        try:
            wf, used_seed, used_det_seed = get_modified_workflow(
                strength        = job.get("strength", 1.0),
                lora_name       = job.get("lora", ""),
                det_lora_name   = job.get("det_lora", ""),
                positive_prompt = job.get("positive", None),
                negative_prompt = job.get("negative", None),
                width           = job.get("width", 1024),
                height          = job.get("height", 1536),
                seed            = job.get("seed", None),
                det_seed        = job.get("det_seed", None),
            )
        except Exception as e:
            reason = f"Erreur construction workflow : {e}"
            logger.error(f"[{jhash}] {reason}")
            save_failed_job(job, reason)
            return False

        logger.debug(f"[{jhash}] seed={used_seed} | det_seed={used_det_seed}")

        # 2. Envoyer à ComfyUI
        prompt_id = send_to_comfy(wf, logger)
        if not prompt_id:
            reason = f"Envoi échoué (tentative {attempt})"
            logger.warning(f"[{jhash}] {reason}")
            if attempt < max_retries:
                time.sleep(RETRY_DELAY)
                continue
            save_failed_job(job, reason)
            return False

        # 3. Attendre la completion
        success, outputs = wait_for_completion(prompt_id, logger, timeout)
        if not success:
            reason = f"Completion échouée (tentative {attempt})"
            logger.warning(f"[{jhash}] {reason}")
            if attempt < max_retries:
                time.sleep(RETRY_DELAY)
                continue
            save_failed_job(job, "Toutes les tentatives ont échoué.")
            return False

        # 4. Contrôle qualité (loopback)
        if quality_check(outputs, logger):
            archive_job(job, prompt_id, used_seed, logger)
            logger.info(f"[{jhash}] ✓ Job validé et archivé.")
            return True
        else:
            logger.warning(
                f"[{jhash}] Contrôle qualité échoué "
                f"(tentative {attempt}/{max_retries}) — relance."
            )
            if attempt < max_retries:
                time.sleep(RETRY_DELAY)
                continue

    save_failed_job(job, "Contrôle qualité échoué après tous les retries.")
    return False


# ============================================================
# BATCH PROCESSING AVANCÉ
# ============================================================
def run_batch_advanced(jobs: list, run_id: str = None) -> dict:
    """
    Traite une liste de jobs sans aucune intervention humaine.

    Fonctionnalités :
      - Retry automatique par job (indépendant des autres)
      - Log détaillé par run dans logs/<run_id>.log
      - Jobs échoués sauvegardés dans workspace/failed_jobs.json
      - Archive structurée dans workspace/archive/
      - Bilan final complet

    Retourne un dict de résultats :
        {
          "run_id":   str,
          "total":    int,
          "success":  int,
          "failed":   int,
          "skipped":  int,
          "results":  [{"job": dict, "status": "ok"|"failed", "hash": str}]
        }
    """
    init_workspace()
    run_id = run_id or f"run_{timestamp()}"
    logger = get_logger(run_id)

    logger.info(f"{'='*60}")
    logger.info(f"BATCH DÉMARRÉ — run_id={run_id} | {len(jobs)} jobs")
    logger.info(f"{'='*60}")

    results = []
    n_ok = n_fail = n_skip = 0

    for i, job in enumerate(jobs):
        logger.info(f"\n--- JOB {i+1}/{len(jobs)} ---")

        # Validation minimale du job
        if not isinstance(job, dict):
            logger.error(f"Job {i+1} invalide (pas un dict), ignoré.")
            n_skip += 1
            results.append({"job": job, "status": "skipped", "hash": "?"})
            continue

        jhash = job_hash(job)
        ok = run_job(job, logger)

        if ok:
            n_ok += 1
            results.append({"job": job, "status": "ok",     "hash": jhash})
        else:
            n_fail += 1
            results.append({"job": job, "status": "failed", "hash": jhash})

    # Bilan
    logger.info(f"\n{'='*60}")
    logger.info(
        f"BATCH TERMINÉ — run_id={run_id} | "
        f"✓ {n_ok} OK | ✗ {n_fail} échoués | ⊘ {n_skip} ignorés"
    )
    logger.info(f"Logs       : {LOGS_DIR / (run_id + '.log')}")
    logger.info(f"Archive    : {ARCHIVE_DIR}")
    logger.info(f"Échecs     : {FAILED_FILE}")
    logger.info(f"{'='*60}")

    return {
        "run_id":  run_id,
        "total":   len(jobs),
        "success": n_ok,
        "failed":  n_fail,
        "skipped": n_skip,
        "results": results
    }


def run_batch_from_config(config_path: str = CONFIG_FILE) -> dict:
    """
    Charge les jobs depuis un fichier config.json et lance run_batch_advanced.
    Point d'entrée pour la Black Box : python agent_supervisor.py
    """
    init_workspace()
    run_id = f"run_{timestamp()}"
    logger = get_logger(run_id)

    try:
        jobs = load_config(config_path)
        logger.info(f"{len(jobs)} jobs chargés depuis {config_path}")
    except Exception as e:
        logger.error(f"Impossible de charger {config_path} : {e}")
        return {"run_id": run_id, "total": 0, "success": 0,
                "failed": 0, "skipped": 0, "results": []}

    return run_batch_advanced(jobs, run_id=run_id)


# ============================================================
# POINT D'ENTRÉE — BLACK BOX
# ============================================================
if __name__ == "__main__":
    import sys

    init_workspace()

    # Mode 1 : python agent_supervisor.py config.json
    if len(sys.argv) > 1:
        cfg = sys.argv[1]
        print(f"Chargement des jobs depuis : {cfg}")
        run_batch_from_config(cfg)

    # Mode 2 : jobs définis inline pour test rapide
    else:
        jobs = [
            {
                "lora":     "ton_lora.safetensors",
                "det_lora": "",
                "strength": 1.0,
                "width":    1024,
                "height":   1536,
                "positive": "masterpiece, best quality, amazing quality, absurdres, 1girl, solo, looking at viewer,",
            },
            # Ajoute autant de jobs que nécessaire :
            # {
            #     "lora":     "autre_lora.safetensors",
            #     "strength": 0.8,
            #     "width":    896,
            #     "height":   1152,
            #     "seed":     42,
            # },
        ]
        run_batch_advanced(jobs)
