import sys
import json
import random

# --- CONFIGURATION ---
LORA_ID = "62"
# Note: Les nœuds ControlNet 165/167/171/172 ne sont pas dans le fichier API exporté.
# Le seul nœud avec 'strength' disponible est le 68 (DifferentialDiffusion).
# Si tu veux contrôler l'intensité globale, c'est lui qu'on cible.
DIFFERENTIAL_DIFFUSION_ID = "68"

def update_workflow(json_file, lora_name, strength, positive_prompt=None, negative_prompt=None, seed=None):
    with open(json_file, 'r', encoding='utf-8') as f:
        workflow = json.load(f)

    # 1. Seed : générer un seed valide si non fourni ou si -1
    if seed is None or seed < 0:
        seed = random.randint(1, 999999999999)
    workflow["112"]["inputs"]["seed"] = seed
    print(f"  Seed: {seed}")

    # 2. LoRA : mise à jour via le champ 'loras.__value__'
    if lora_name and lora_name.strip():
        workflow[LORA_ID]["inputs"]["loras"] = {
            "__value__": [
                {"lora": lora_name, "strength": 1.0, "enabled": True}
            ]
        }
        print(f"  LoRA: {lora_name}")
    else:
        # Pas de LoRA
        workflow[LORA_ID]["inputs"]["loras"] = {"__value__": []}
        print(f"  LoRA: aucun")

    # 3. Strength (DifferentialDiffusion)
    if DIFFERENTIAL_DIFFUSION_ID in workflow:
        workflow[DIFFERENTIAL_DIFFUSION_ID]["inputs"]["strength"] = strength
        print(f"  DifferentialDiffusion strength: {strength}")

    # 4. Prompt positif (inline dans les StringConcatenate)
    if positive_prompt:
        workflow["87"]["inputs"]["string_b"] = positive_prompt
        workflow["99"]["inputs"]["string_a"] = positive_prompt
        print(f"  Positive: {positive_prompt[:60]}...")

    # 5. Prompt négatif (inline dans CLIPTextEncode + Image Saver)
    if negative_prompt:
        workflow["111"]["inputs"]["text"] = negative_prompt
        workflow["129"]["inputs"]["negative"] = negative_prompt
        print(f"  Negative: {negative_prompt[:60]}...")

    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(workflow, f, indent=2, ensure_ascii=False)

    print(f"  Workflow mis à jour dans {json_file}")

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python orchestrator.py <fichier.json> <lora_name> <strength> [positive_prompt] [seed]")
        print('Exemple: python orchestrator.py "Advanced_QwenVL_V35_API_fixed.json" "my_lora.safetensors" 0.8')
        sys.exit(1)

    json_file = sys.argv[1]
    lora_name = sys.argv[2]
    strength = float(sys.argv[3])
    positive_prompt = sys.argv[4] if len(sys.argv) > 4 else None
    seed = int(sys.argv[5]) if len(sys.argv) > 5 else None

    update_workflow(json_file, lora_name, strength, positive_prompt=positive_prompt, seed=seed)
