@echo off
chcp 65001 >nul
title ComfyUI — OverLord Pipeline
cd /d "D:\OVERLORD"

echo ============================================================
echo    ComfyUI — Lancement
echo ============================================================
echo(

:: Chercher ComfyUI dans les emplacements courants (D: en priorité)
set COMFY_PATH=

if exist "D:\ComfyUI_windows_portable\run_nvidia_gpu.bat"     set COMFY_PATH=D:\ComfyUI_windows_portable
if exist "D:\ComfyUI\run_nvidia_gpu.bat"                      set COMFY_PATH=D:\ComfyUI
if exist "D:\AI\ComfyUI_windows_portable\run_nvidia_gpu.bat"  set COMFY_PATH=D:\AI\ComfyUI_windows_portable
if exist "D:\IA Local\ComfyUI_windows_portable\run_nvidia_gpu.bat" set COMFY_PATH=D:\IA Local\ComfyUI_windows_portable
if exist "C:\ComfyUI_windows_portable\run_nvidia_gpu.bat"     set COMFY_PATH=C:\ComfyUI_windows_portable
if exist "C:\ComfyUI\run_nvidia_gpu.bat"                      set COMFY_PATH=C:\ComfyUI

:: Si trouvé automatiquement
if not "%COMFY_PATH%"=="" goto :FOUND

:: Pas trouvé — demander le chemin manuellement
echo [INFO] ComfyUI non détecté automatiquement.
echo(
echo Entrez le chemin complet vers votre dossier ComfyUI
echo (celui qui contient run_nvidia_gpu.bat)
echo Exemple : D:\ComfyUI_windows_portable
echo(
set /p COMFY_PATH=Chemin ComfyUI : 

if "%COMFY_PATH%"=="" (
    echo [ERREUR] Aucun chemin entré.
    pause
    exit /b 1
)

if not exist "%COMFY_PATH%\run_nvidia_gpu.bat" (
    echo [ERREUR] run_nvidia_gpu.bat introuvable dans : %COMFY_PATH%
    echo Vérifie le chemin et réessaie.
    pause
    exit /b 1
)

:: Sauvegarder le chemin pour la prochaine fois
echo COMFY_PATH=%COMFY_PATH% > "D:\OVERLORD\comfy_path.cfg"
echo [OK] Chemin sauvegardé pour la prochaine fois.

:FOUND
echo [OK] ComfyUI trouvé : %COMFY_PATH%
echo(
echo Arguments : --disable-smart-memory --normalvram --cpu-vae
echo             --use-pytorch-cross-attention --preview-method none
echo             --disable-auto-launch
echo(
echo Lancement en cours...
echo(

cd /d "%COMFY_PATH%"
python main.py ^
    --disable-smart-memory ^
    --normalvram ^
    --cpu-vae ^
    --use-pytorch-cross-attention ^
    --preview-method none ^
    --disable-auto-launch

pause
