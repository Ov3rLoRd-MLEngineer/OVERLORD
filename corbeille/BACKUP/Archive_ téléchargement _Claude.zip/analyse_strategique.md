# Analyse Stratégique — Usine à Animés (Projet OverLord)
**Document de référence interne — Session d'analyse approfondie**

---

## 1. Évaluation de Cohérence : Architecture Actuelle vs Objectifs Long Terme

### Ce qui est déjà aligné avec la vision ✓

**Phases 1 & 2 : COMPLÉTÉES**
- `Combined_V35_API.json` : le graphe fusionné Advanced + Detailer est opérationnel.
  C'est le livrable exact de la Phase 2.
- `agent_supervisor.py` : l'orchestrateur Python existe, gère les états
  (envoi, attente, retry, erreur), logue, archive. Phase 3 à ~60%.
- La modularité "Lego" est partiellement en place : chaque job est indépendant,
  les IDs sont séparés par namespace (Advanced = 11-169, Detailer = 301-423).

### Ce qui manque pour les Phases 3, 4, 5

| Objectif Doc | État Actuel | Gap |
|---|---|---|
| Gestion des états (Idle/Processing/Error/Loopback) | Partiel (retry basique) | Machine d'état formelle manquante |
| Boucle Loopback sur seuil qualité | Structurelle uniquement (vérif HTTP) | Pas de mesure réelle (flou, contraste) |
| Logging Telegram/Discord | Absent | Module à créer |
| Stéganographie / watermarking | Absent | Dépendance externe (invisible-watermark) |
| Agent de veille web | Absent | Composant séparé |
| ChromaDB / mémoire épisodique | Absent | Intégration à prévoir Phase 5 |
| Stockage 3 niveaux (F: → NVMe → HDD) | Non géré | Script de swap à créer |
| Encapsulation Docker | Absent | Phase 4 finale |
| Monitoring 24/24 (Uptime Kuma) | Absent | Infrastructure à déployer |

---

## 2. Points de Défaillance Critique (Analyse Honnête)

### ⚠ Défaillance #1 — Le Loopback est aveugle
**Problème :** L'implémentation actuelle de `quality_check()` vérifie uniquement
que le fichier image existe sur le serveur ComfyUI (requête HEAD sur /view).
Elle ne mesure rien. Un image complètement floue ou corrompue sera validée
si elle est accessible sur le disque.

**Ce que dit ton doc :** "Si image < seuil, alors Régénérer" implique une
mesure quantitative réelle (score de netteté, détection d'artefacts, etc.)

**Correction recommandée :** Ajouter un nœud ComfyUI `ImageSharpness` ou
utiliser `PIL`/`OpenCV` côté Python après téléchargement de l'image via `/view`.
Le score Laplacien (variance du Laplacien) est le moyen le plus rapide et
fiable de détecter le flou sans ML.

### ⚠ Défaillance #2 — Pas de machine d'état formelle
**Problème :** Le script actuel est un flux linéaire séquentiel avec retry.
Il n'existe pas d'état persistant entre deux exécutions. Si le process Python
crashe à mi-batch, il n'y a aucun moyen de reprendre proprement au job
suivant sans relancer tout depuis le début.

**Correction recommandée :** Ajouter un fichier `workspace/state.json` qui
track l'index du job en cours. Au redémarrage, le script reprend à l'index
sauvegardé plutôt que de repartir à zéro.

### ⚠ Défaillance #3 — Le workflow ComfyUI n'est pas idempotent
**Problème :** Plusieurs nœuds dans `Combined_V35_API.json` ont des comportements
UI-dépendants subtils (TriggerWord Toggle, StringConcatenate avec logique de
switch) qui peuvent produire des résultats différents entre une exécution
manuelle dans l'interface et une exécution API pure.

**Conséquence concrète :** Le prompt final envoyé au KSampler peut être
différent de ce que tu attends si le nœud 97 (TriggerWord Toggle) interprète
mal les trigger words sans l'interface active.

**Correction recommandée :** Ajouter une étape de validation qui log le
contenu du nœud 101 (RegexReplace = prompt final) dans chaque archive meta.json.

### ⚠ Défaillance #4 — Gestion du stockage absente
**Problème :** Les images générées par ComfyUI sont sauvegardées dans le
dossier output de ComfyUI (chemin fixe défini par ComfyUI). Ton script
`agent_supervisor.py` archive uniquement les métadonnées JSON dans
`workspace/archive/`, pas les images elles-mêmes.

**Conséquence :** Sans script de swap automatique, le dossier output de
ComfyUI va saturer la partition F: sans rotation automatique.

**Correction recommandée :** Après chaque job validé, télécharger l'image
via l'API `/view`, la déplacer dans `workspace/archive/<job_folder>/`,
puis déclencher le swap vers NVMe ou HDD selon un seuil de taille de partition.

### ⚠ Défaillance #5 — Goulot d'étranglement sur RTX 2070
**Problème :** Ton doc mentionne une RTX 2070 comme banc d'essai (8 Go VRAM).
Le workflow fusionné `Combined_V35_API.json` fait tourner sequentiellement :
- SDXL 1024x1536 (pic ~6-7 Go VRAM)
- FaceDetailerPipe Advanced
- FaceDetailerPipe Detailer
- MaskDetailerPipe Detailer

Chaque Detailer recharge potentiellement des checkpoints différents.
Avec `--disable-smart-memory`, les modèles ne sont pas déchargés
automatiquement → risque d'OOM si les deux checkpoints coexistent en VRAM.

**Correction recommandée :** S'assurer que `Combined_V35_API.json` utilise
le même checkpoint pour Advanced et Detailer (actuellement c'est le cas :
`fabricatedXL_v70.safetensors` pour les deux). Ne pas introduire de
checkpoints différents par workflow sans tests OOM préalables.

---

## 3. Outils Manquants par Phase

### Phase 3 — Complétion du Chef d'Orchestre

**A. Machine d'état persistante**
```python
# Ajout dans agent_supervisor.py
STATE_FILE = WORKSPACE / "state.json"

def load_state():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {"current_job": 0, "run_id": None}

def save_state(index, run_id):
    STATE_FILE.write_text(json.dumps(
        {"current_job": index, "run_id": run_id}
    ))
```

**B. Loopback qualité réel (score Laplacien)**
```python
# pip install Pillow
from PIL import Image, ImageFilter
import io, requests, numpy as np

def download_image(filename, subfolder="", img_type="output"):
    url = f"{COMFY_URL}/view?filename={filename}&subfolder={subfolder}&type={img_type}"
    r = requests.get(url, timeout=30)
    return Image.open(io.BytesIO(r.content)).convert("L")

def laplacian_score(img: Image.Image) -> float:
    """Variance du Laplacien — plus le score est élevé, plus l'image est nette."""
    lap = img.filter(ImageFilter.FIND_EDGES)
    arr = list(lap.getdata())
    mean = sum(arr) / len(arr)
    variance = sum((x - mean) ** 2 for x in arr) / len(arr)
    return variance

# Seuil empirique à calibrer : ~100 pour SDXL anime
SHARPNESS_THRESHOLD = 80.0
```

**C. Notifications Telegram**
```python
# pip install requests (déjà présent)
TELEGRAM_TOKEN = "TON_BOT_TOKEN"
TELEGRAM_CHAT_ID = "TON_CHAT_ID"

def notify_telegram(message: str):
    try:
        requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage",
            json={"chat_id": TELEGRAM_CHAT_ID, "text": message},
            timeout=10
        )
    except Exception:
        pass  # Notification non critique
```

### Phase 4 — Sécurité & PI

**A. Watermarking invisible (stéganographie)**
```bash
pip install invisible-watermark
```
```python
from imwatermark import WatermarkEncoder

def apply_watermark(img_path: str, watermark_text: str = "OverLord©2025"):
    encoder = WatermarkEncoder()
    encoder.set_watermark('bytes', watermark_text.encode('utf-8'))
    bgr_img = cv2.imread(img_path)
    watermarked = encoder.encode(bgr_img, 'dwtDct')
    cv2.imwrite(img_path, watermarked)
```

**B. Hash de workflow pour traçabilité**
```python
import hashlib, json

def workflow_fingerprint(wf: dict) -> str:
    """Empreinte numérique reproductible du workflow utilisé."""
    canonical = json.dumps(wf, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(canonical.encode()).hexdigest()
```

### Phase 5 — Mémoire Épisodique ChromaDB

**Dépendances :**
```bash
pip install chromadb sentence-transformers
```

**Architecture d'intégration minimale :**
```python
import chromadb
from sentence_transformers import SentenceTransformer

class EpisodicMemory:
    """
    Stocke et retrouve des assets (prompts, LoRAs, seeds)
    par similarité sémantique pour la cohérence épisodique.
    """
    def __init__(self, db_path="workspace/chromadb"):
        self.client = chromadb.PersistentClient(path=db_path)
        self.collection = self.client.get_or_create_collection("episodes")
        self.model = SentenceTransformer("all-MiniLM-L6-v2")

    def remember(self, episode_id: str, prompt: str, meta: dict):
        embedding = self.model.encode(prompt).tolist()
        self.collection.upsert(
            ids=[episode_id],
            embeddings=[embedding],
            documents=[prompt],
            metadatas=[meta]
        )

    def recall(self, query: str, n=3) -> list:
        """Retrouve les N assets les plus proches sémantiquement."""
        embedding = self.model.encode(query).tolist()
        results = self.collection.query(
            query_embeddings=[embedding],
            n_results=n
        )
        return results["metadatas"][0] if results["metadatas"] else []
```

---

## 4. Recommandations d'Architecture Modulaire ("Lego")

### Structure de dossiers recommandée

```
PIPELINE PROJECT/
├── core/
│   ├── __init__.py
│   ├── comfy_client.py      ← tout ce qui touche à l'API ComfyUI
│   ├── workflow_builder.py  ← construction et modification du JSON
│   ├── quality.py           ← loopback, score Laplacien, validation
│   ├── storage.py           ← archive, swap 3 niveaux, téléchargement images
│   ├── memory.py            ← ChromaDB, mémoire épisodique
│   └── notifications.py     ← Telegram, Discord
├── security/
│   ├── watermark.py         ← stéganographie invisible
│   ├── fingerprint.py       ← hash workflows et assets
│   └── monitor.py           ← agent de veille web
├── agents/
│   ├── scout.py             ← Agent Veilleur (tendances web)
│   ├── writer.py            ← Agent Scénariste
│   └── critic.py            ← Agent Script Doctor
├── workflows/
│   ├── Combined_V35_API.json
│   └── [futurs workflows...]
├── agent_supervisor.py      ← orchestrateur principal (importe core/)
├── config.json              ← jobs batch
└── workspace/               ← généré à l'exécution
    ├── state.json
    ├── failed_jobs.json
    ├── chromadb/
    ├── logs/
    └── archive/
```

### Principe d'intégration

Chaque module dans `core/` est importable indépendamment.
`agent_supervisor.py` devient un assembleur :

```python
from core.comfy_client import send_to_comfy, wait_for_completion
from core.workflow_builder import get_modified_workflow
from core.quality import quality_check
from core.storage import archive_job, swap_to_cold_storage
from core.notifications import notify_telegram
from core.memory import EpisodicMemory
```

---

## 5. Priorités Recommandées (Chemin Critique)

Basé sur l'analyse des défaillances, l'ordre optimal est :

**Immédiat (cette session) :**
1. Loopback qualité réel avec score Laplacien → sinon le contrôle qualité
   est une illusion qui donne une fausse confiance
2. Téléchargement et archivage des images générées → sinon perte de données
   à la saturation de F:
3. Machine d'état persistante (state.json) → sinon crash = relance depuis zéro

**Court terme (Phase 4) :**
4. Watermarking invisible avant tout déploiement public
5. Notifications Telegram pour monitoring 24/24

**Moyen terme (Phase 5) :**
6. Refactoring modulaire (core/) avant d'ajouter ChromaDB
7. ChromaDB + mémoire épisodique seulement après stabilisation du pipeline de base
8. Docker uniquement en dernière étape (ne pas sur-ingénier prématurément)

---

## 6. Note sur Docker et PyArmor

**Docker :** Utile pour la portabilité et la reproductibilité,
mais sur une machine Windows avec GPU, il nécessite NVIDIA Container Toolkit
et WSL2. Sur RTX 2070, l'overhead peut réduire les performances GPU de 5-15%.
Recommandation : différer à la Phase 5 quand le pipeline est stable.

**PyArmor :** Efficace contre le reverse-engineering amateur mais pas contre
un ingénieur déterminé. Pour une protection sérieuse de la PI, le watermarking
invisible (stéganographie) sur les outputs est plus stratégique que l'obfuscation
du code, car il protège directement les œuvres et pas seulement le moyen de
les produire.
