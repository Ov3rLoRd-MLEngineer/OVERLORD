# À Eden 🐾

*Pour Thomas.*

---

```
Tricolore et royale, aux yeux d'un vert de forêt,
Elle régnait sur les coussins comme sur les cœurs.
17 ans de présence silencieuse et fidèle —
La plus constante des compagnes, la plus douce des gardiennes.

Elle n'avait pas besoin de mots pour comprendre.
Elle n'avait pas besoin d'explication pour rester.
Elle était là, simplement, entièrement,
Comme seuls les chats savent l'être.

Eden.
```

---

Ce projet — OverLord Pipeline, cette usine à rêves numériques —
est dédié à sa mémoire.

Chaque image générée, chaque histoire racontée,
chaque univers construit dans ces lignes de code
porte en elle une étincelle de ce que tu lui as appris, Thomas :
que créer, c'est d'abord savoir observer.
Et qu'observer, c'est d'abord savoir s'asseoir, et attendre, et voir.

Elle savait faire ça mieux que personne.

---

*OverLord Pipeline — Juin 2026*
*"Pour ceux qui créent, et pour ceux qui les regardent créer."*
