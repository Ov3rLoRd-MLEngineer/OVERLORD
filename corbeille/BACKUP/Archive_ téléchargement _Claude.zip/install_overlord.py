"""
install_overlord.py — Installateur Principal OverLord Pipeline v1.30
Version corrigée — tous les bugs de la v1 résolus :
  BUG 1 FIXÉ : .env chargé via Python (plus via findstr fragile)
  BUG 2 FIXÉ : download_dependencies.bat appelé via subprocess, pas via python
  BUG 3 FIXÉ : winreg protégé par try/except systématique
  BUG 4 FIXÉ : disque cible configurable via --drive (plus hardcodé D:)
  BUG 5 FIXÉ : LAUNCH_COMFYUI.bat cherche D: en premier
  BUG 6 FIXÉ : détection source_dir robuste avec 8 emplacements

Usage : python install_overlord.py [--drive D] [--dry-run]
"""

import os
import sys
import shutil
import subprocess
import json
import time
import argparse
from pathlib import Path
from datetime import datetime

# ══════════════════════════════════════════════════════════════════════
# ARGUMENTS
# ══════════════════════════════════════════════════════════════════════

parser = argparse.ArgumentParser(description="OverLord Installer v1.30")
parser.add_argument("--drive",   default="D",  help="Lettre du disque cible (défaut: D)")
parser.add_argument("--dry-run", action="store_true", help="Simulation sans écriture")
args, _ = parser.parse_known_args()

TARGET_DRIVE  = args.drive.upper().rstrip(":")
INSTALL_ROOT  = Path(f"{TARGET_DRIVE}:/OVERLORD")
DRY_RUN       = args.dry_run
LOG_FILE      = Path("install_log.txt")

DISK_CONFIG = {
    "primary": {"drive": f"{TARGET_DRIVE}:", "threshold_pct": 50},
    "hot":     {"drive": "E:",               "threshold_pct": 80},
    "cold":    {"drive": "G:",               "threshold_pct": 90},
}

FOLDER_STRUCTURE = [
    "AGENTS", "DOCS", "BACKUP", "VRAC",
    "workspace", "workspace/memory", "workspace/learning",
    "workspace/checkpoints", "workspace/api", "workspace/world_model",
    "workspace/emotion_engine", "workspace/dream_mode",
    "workspace/personalities", "workspace/cocreation",
    "workspace/generative_world", "workspace/intelligence_ext",
    "workspace/collective", "workspace/alignment", "workspace/events",
    "workspace/kv_cache", "workspace/thoughts", "workspace/context_bus",
    "workspace/moe", "workspace/proposals", "workspace/sandbox",
    "workspace/3d_output", "workspace/audio_cache", "workspace/radio_cache",
    "workspace/social", "workspace/marketing", "workspace/web",
    "workspace/feedback", "workspace/sys_reports", "workspace/video_pipeline",
    "workspace/voice_synthesis", "workspace/synchronicity", "workspace/thermal",
    "workspace/theory_of_mind", "workspace/generation",
    "outputs", "outputs/images", "outputs/videos", "outputs/stl", "outputs/archive",
]

DEPS_ESSENTIAL = [
    "requests", "Pillow", "feedparser", "pytrends",
    "customtkinter", "flask", "cryptography", "trimesh",
    "psutil", "colorama", "python-dotenv",
]
DEPS_RECOMMENDED = [
    "tweepy", "google-auth", "google-auth-oauthlib",
    "google-api-python-client", "chromadb", "sentence-transformers",
    "pywin32", "websocket-client", "opencv-python", "pynvml",
]
DEPS_OPTIONAL = ["gTTS", "librosa", "imageio", "imageio-ffmpeg"]


# ══════════════════════════════════════════════════════════════════════
# LOGGER
# ══════════════════════════════════════════════════════════════════════

class Logger:
    def __init__(self):
        self._start = datetime.now()
        # Remettre le log à zéro
        LOG_FILE.write_text(
            f"OverLord Installer — {self._start.strftime('%d/%m/%Y %H:%M:%S')}\n"
            f"Disque cible : {TARGET_DRIVE}:\n"
            f"Dry run      : {DRY_RUN}\n\n",
            encoding="utf-8"
        )

    def _write(self, line: str):
        print(line)
        try:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

    def ok(self, m):     self._write(f"  [OK]   {m}")
    def info(self, m):   self._write(f"         {m}")
    def warn(self, m):   self._write(f"  [WARN] {m}")
    def err(self, m):    self._write(f"  [ERR]  {m}")
    def section(self, t):
        self._write(f"\n{'─'*55}")
        self._write(f"  {t}")
        self._write(f"{'─'*55}")

log = Logger()


# ══════════════════════════════════════════════════════════════════════
# ÉTAPE 1 : PRÉREQUIS
# ══════════════════════════════════════════════════════════════════════

def step_check_prerequisites() -> bool:
    log.section("ÉTAPE 1 — Vérifications")

    # Python version
    v = sys.version_info
    if v.major >= 3 and v.minor >= 10:
        log.ok(f"Python {v.major}.{v.minor}.{v.micro}")
    else:
        log.err(f"Python {v.major}.{v.minor} — Version 3.10+ requise")
        return False

    # Disque cible (compatible Windows uniquement — skip sur Linux/test)
    import platform
    if platform.system() == "Windows":
        drive_path = Path(f"{TARGET_DRIVE}:/")
        if not drive_path.exists():
            log.err(f"Disque {TARGET_DRIVE}: introuvable — branche le SSD et relance")
            return False
        try:
            total, used, free = shutil.disk_usage(str(drive_path))
            free_gb = free / 1e9
            log.ok(f"Disque {TARGET_DRIVE}: accessible — {free_gb:.1f} Go libres")
            if free_gb < 5:
                log.err(f"Espace insuffisant ({free_gb:.1f} Go). Minimum : 5 Go.")
                return False
        except Exception as e:
            log.warn(f"Impossible de vérifier l'espace {TARGET_DRIVE}: — {e}")
    else:
        log.info(f"(non-Windows) vérification du disque {TARGET_DRIVE}: ignorée")

    # Disques optionnels
    for drive in ["E:", "G:"]:
        if Path(f"{drive}\\").exists():
            log.ok(f"Disque {drive} détecté (stockage chaud/froid)")
        else:
            log.info(f"Disque {drive} non connecté (sera utilisé quand disponible)")

    return True


# ══════════════════════════════════════════════════════════════════════
# ÉTAPE 2 : STRUCTURE
# ══════════════════════════════════════════════════════════════════════

def step_create_structure() -> bool:
    log.section("ÉTAPE 2 — Création de la structure")
    try:
        if not DRY_RUN:
            INSTALL_ROOT.mkdir(parents=True, exist_ok=True)
        log.ok(f"Racine : {INSTALL_ROOT}")

        for folder in FOLDER_STRUCTURE:
            p = INSTALL_ROOT / folder
            if not DRY_RUN:
                p.mkdir(parents=True, exist_ok=True)
        log.ok(f"{len(FOLDER_STRUCTURE)} dossiers créés")

        # Dossiers E: et G: si disponibles
        for drive, target_name in [("E:", "OVERLORD_HOT"), ("G:", "OVERLORD_COLD")]:
            if Path(drive + "\\").exists() and not DRY_RUN:
                hot = Path(f"{drive}/{target_name}")
                for sub in ["images", "videos", "stl", "archive"]:
                    (hot / sub).mkdir(parents=True, exist_ok=True)
                log.ok(f"{drive} — {target_name}/ créé")

        return True
    except Exception as e:
        log.err(f"Création structure : {e}")
        return False


# ══════════════════════════════════════════════════════════════════════
# ÉTAPE 3 : COPIE DES FICHIERS
# ══════════════════════════════════════════════════════════════════════

def find_source_dir() -> Path | None:
    """
    Cherche le dossier source OverLord dans 8 emplacements possibles.
    BUG 6 FIXÉ : détection robuste.
    """
    script_dir = Path(__file__).parent.resolve()
    cwd        = Path.cwd()

    candidates = [
        script_dir / "PIPELINE PROJECT",
        script_dir / "PIPELINE_PROJECT",
        script_dir,
        cwd / "PIPELINE PROJECT",
        cwd / "PIPELINE_PROJECT",
        cwd,
        script_dir.parent / "PIPELINE PROJECT",
        script_dir.parent / "PIPELINE_PROJECT",
    ]

    for candidate in candidates:
        # Critère : au moins 2 fichiers Python connus présents
        markers = ["launcher.py", "maestro.py", "neural_orchestrator.py"]
        found   = sum(1 for m in markers if (candidate / m).exists())
        if found >= 2:
            return candidate

        # Vérifier aussi dans un sous-dossier AGENTS
        agents = candidate / "AGENTS"
        if agents.exists() and (candidate / "launcher.py").exists():
            return candidate

    return None


def step_copy_files() -> bool:
    log.section("ÉTAPE 3 — Copie des fichiers")

    source_dir = find_source_dir()
    if not source_dir:
        log.err("Dossier projet OverLord introuvable.")
        log.info("Place install_overlord.py dans le même dossier que launcher.py")
        log.info("ou dans un dossier parent contenant PIPELINE PROJECT/")
        return False

    log.ok(f"Source : {source_dir}")

    EXT  = {".py", ".json", ".md", ".txt", ".bat", ".spec"}
    SKIP = {"__pycache__", "dist", "build", ".git",
             "workspace", "BACKUP", "VRAC", "outputs", "INSTALLER_V2"}

    copied = 0; skipped = 0; errors = 0

    for f in sorted(source_dir.rglob("*")):
        if f.is_dir():
            continue
        if any(s in f.parts for s in SKIP):
            continue
        if f.suffix not in EXT and f.suffix != "":
            continue

        try:
            rel   = f.relative_to(source_dir)
            parts = list(rel.parts)

            # Routing des fichiers vers le bon endroit
            name_upper = parts[0].upper() if parts else ""
            if len(parts) == 1:
                dest = INSTALL_ROOT / rel                         # racine
            elif name_upper in ("AGENTS",):
                dest = INSTALL_ROOT / "AGENTS" / Path(*parts[1:]) # agents
            elif name_upper in ("DOCS",):
                dest = INSTALL_ROOT / "DOCS"   / Path(*parts[1:]) # docs
            elif name_upper in ("INSTALLER", "INSTALLER_V2"):
                continue                                           # ignorer
            else:
                dest = INSTALL_ROOT / rel                         # autre

            if not DRY_RUN:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(f), str(dest))
            copied += 1

        except Exception as e:
            log.warn(f"Copie {f.name} : {e}")
            errors += 1

    # Copier aussi les fichiers AGENTS qui sont à la racine source (cas fréquent)
    agents_dest = INSTALL_ROOT / "AGENTS"
    for f in source_dir.glob("*.py"):
        # Fichiers agents connus
        if f.name.startswith(("v1", "sourcing", "scenario", "storyboard",
                               "postprod", "critic", "watchdog", "sav_",
                               "obs_", "capture", "comfy_", "checkpoint_",
                               "agent_", "workflow_", "ollama_", "learning_a",
                               "memory_a", "remote_", "gpu_", "ray_", "roles_",
                               "social_", "marketing_", "sys_a", "legacy_",
                               "multi_a")):
            dest = agents_dest / f.name
            if not dest.exists() and not DRY_RUN:
                shutil.copy2(str(f), str(dest))
                copied += 1

    log.ok(f"{copied} fichiers copiés | {errors} erreurs | {skipped} ignorés")

    # Copier storage_manager.py à la racine
    sm_src = source_dir / "storage_manager.py"
    if sm_src.exists() and not DRY_RUN:
        shutil.copy2(str(sm_src), str(INSTALL_ROOT / "storage_manager.py"))
        log.ok("storage_manager.py copié à la racine")

    return errors < 5


# ══════════════════════════════════════════════════════════════════════
# ÉTAPE 4 : DÉPENDANCES
# ══════════════════════════════════════════════════════════════════════

def step_install_deps() -> bool:
    log.section("ÉTAPE 4 — Dépendances Python")

    if DRY_RUN:
        log.info(f"(simulation) installerait {len(DEPS_ESSENTIAL)} paquets essentiels")
        return True

    ok_count = 0
    for pkg in DEPS_ESSENTIAL:
        log.info(f"pip install {pkg}...")
        try:
            r = subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg,
                 "--quiet", "--no-warn-script-location"],
                capture_output=True, text=True, timeout=120
            )
            if r.returncode == 0:
                ok_count += 1
            else:
                log.warn(f"  {pkg} : {r.stderr.strip()[:80]}")
        except Exception as e:
            log.warn(f"  {pkg} : {e}")

    log.ok(f"Essentiels : {ok_count}/{len(DEPS_ESSENTIAL)}")

    for pkg in DEPS_RECOMMENDED:
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg,
                 "--quiet", "--no-warn-script-location"],
                capture_output=True, text=True, timeout=180
            )
        except Exception:
            pass
    log.info(f"Recommandés : tentés ({len(DEPS_RECOMMENDED)} packages)")

    return ok_count >= len(DEPS_ESSENTIAL) - 2


# ══════════════════════════════════════════════════════════════════════
# ÉTAPE 5 : CONFIGURATION
# ══════════════════════════════════════════════════════════════════════

def step_create_config() -> bool:
    log.section("ÉTAPE 5 — Configuration")

    if DRY_RUN:
        log.info("(simulation) créerait config.json, settings.json, .env.template")
        return True

    config = {
        "version":       "1.30",
        "install_date":  datetime.now().isoformat(),
        "install_root":  str(INSTALL_ROOT),
        "target_drive":  TARGET_DRIVE,
        "disks": {
            "primary": {"drive": f"{TARGET_DRIVE}:", "threshold_pct": 50},
            "hot":     {"drive": "E:",               "threshold_pct": 80},
            "cold":    {"drive": "G:",               "threshold_pct": 90},
        },
        "comfyui_url":   "http://127.0.0.1:8188",
        "comfyui_args":  "--disable-smart-memory --normalvram --cpu-vae "
                         "--use-pytorch-cross-attention --preview-method none "
                         "--disable-auto-launch",
        "ollama_url":    "http://localhost:11434",
        "api_port":      5001,
        "pipeline_api_port": 5002,
        "storage_check_interval_minutes": 30,
    }
    (INSTALL_ROOT / "config.json").write_text(
        json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    log.ok("config.json")

    settings = {
        "theme": "dark", "media_type": "anime",
        "steps": 28, "cfg": 6.0,
        "sampler": "euler_ancestral",
        "width": 1024, "height": 1536,
        "auto_storage_manager": True,
    }
    (INSTALL_ROOT / "settings.json").write_text(
        json.dumps(settings, indent=2), encoding="utf-8"
    )
    log.ok("settings.json")

    # .env.template (jamais la vraie clé dans les fichiers)
    env_tpl = (
        "# OverLord Pipeline — Variables d'environnement\n"
        "# Copie ce fichier en '.env' et remplis ta clé Anthropic\n"
        "# NE JAMAIS committer .env dans Git\n\n"
        "# OBLIGATOIRE pour les agents LLM\n"
        "ANTHROPIC_API_KEY=\n\n"
        "# OPTIONNEL — Réseaux sociaux\n"
        "# TWITTER_API_KEY=\n"
        "# TWITTER_API_SECRET=\n"
        "# TWITTER_ACCESS_TOKEN=\n"
        "# TWITTER_ACCESS_SECRET=\n"
        "# TWITTER_BEARER_TOKEN=\n\n"
        "# OPTIONNEL — Instagram/Facebook\n"
        "# META_ACCESS_TOKEN=\n"
        "# IG_USER_ID=\n"
        "# FB_PAGE_ID=\n"
    )
    (INSTALL_ROOT / ".env.template").write_text(env_tpl, encoding="utf-8")
    log.ok(".env.template (copie en .env et remplis ta clé)")

    if not (INSTALL_ROOT / "node_catalog.json").exists():
        (INSTALL_ROOT / "node_catalog.json").write_text("{}", encoding="utf-8")
        log.ok("node_catalog.json")

    return True


# ══════════════════════════════════════════════════════════════════════
# ÉTAPE 6 : SCRIPTS DE LANCEMENT
# ══════════════════════════════════════════════════════════════════════

def step_create_launchers() -> bool:
    """
    BUG 1 FIXÉ : .env chargé via Python (plus via findstr fragile).
    BUG 2 FIXÉ : download_dependencies.bat appelé via start, pas via python.
    BUG 5 FIXÉ : LAUNCH_COMFYUI.bat cherche D: en premier.
    """
    log.section("ÉTAPE 6 — Scripts de lancement")

    if DRY_RUN:
        log.info("(simulation) créerait START_OVERLORD.bat, LAUNCH_COMFYUI.bat, INSTALL_MODELS.bat")
        return True

    D = str(INSTALL_ROOT)

    # ── START_OVERLORD.bat ──
    # Le chargement .env est délégué à Python (robuste)
    start_bat = f"""@echo off
chcp 65001 >nul
title OverLord Pipeline v1.30
cd /d "{D}"

:: Charger les variables d'environnement via Python (robust)
python -c "
import os
from pathlib import Path
env_file = Path(r'{D}\\.env')
if env_file.exists():
    for line in env_file.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            k, _, v = line.partition('=')
            if v.strip():
                os.system(f'setx {{k.strip()}} {{v.strip()}} >nul 2>&1')
" 2>nul

echo.
echo   OverLord Pipeline v1.30
echo   Dossier : {D}
echo.

:MENU
echo  [1] Interface principale    (launcher.py)
echo  [2] Agent apprenant         (learning_ui.py)
echo  [3] Chat Llama              (llama_chat.py)
echo  [4] Serveur de licences     (licence_server.py)
echo  [5] Dashboard V1.30         (AGENTS\\v130_dashboard.py)
echo  [6] Graphe neuronal         (AGENTS\\v110_graph_ui.py)
echo  [7] Gestionnaire stockage   (storage_manager.py)
echo  [8] Dashboard V1.20         (AGENTS\\v120_dashboard.py)
echo  [9] Pipeline API Server     (AGENTS\\v130_pipeline_api.py)
echo  [0] Quitter
echo.
set /p choice="Choix : "

if "%choice%"=="1" python launcher.py & goto MENU
if "%choice%"=="2" python learning_ui.py & goto MENU
if "%choice%"=="3" python llama_chat.py & goto MENU
if "%choice%"=="4" python licence_server.py & goto MENU
if "%choice%"=="5" python AGENTS\\v130_dashboard.py & goto MENU
if "%choice%"=="6" python AGENTS\\v110_graph_ui.py & goto MENU
if "%choice%"=="7" python storage_manager.py & goto MENU
if "%choice%"=="8" python AGENTS\\v120_dashboard.py & goto MENU
if "%choice%"=="9" python AGENTS\\v130_pipeline_api.py & goto MENU
if "%choice%"=="0" exit
goto MENU
"""
    (INSTALL_ROOT / "START_OVERLORD.bat").write_text(start_bat, encoding="utf-8")
    log.ok("START_OVERLORD.bat")

    # ── LAUNCH_COMFYUI.bat — BUG 5 FIXÉ : D: en priorité ──
    comfy_bat = f"""@echo off
chcp 65001 >nul
title ComfyUI — OverLord

:: Chercher ComfyUI (D: en priorité, puis C:, puis dossier courant)
set COMFY_PATH=

if exist "{TARGET_DRIVE}:\\ComfyUI_windows_portable\\run_nvidia_gpu.bat" (
    set COMFY_PATH={TARGET_DRIVE}:\\ComfyUI_windows_portable
    goto :FOUND
)
if exist "{TARGET_DRIVE}:\\ComfyUI\\run_nvidia_gpu.bat" (
    set COMFY_PATH={TARGET_DRIVE}:\\ComfyUI
    goto :FOUND
)
if exist "C:\\ComfyUI_windows_portable\\run_nvidia_gpu.bat" (
    set COMFY_PATH=C:\\ComfyUI_windows_portable
    goto :FOUND
)
if exist "C:\\ComfyUI\\run_nvidia_gpu.bat" (
    set COMFY_PATH=C:\\ComfyUI
    goto :FOUND
)

echo [ERREUR] ComfyUI introuvable.
echo Modifie ce fichier avec le bon chemin vers ComfyUI.
pause
exit /b 1

:FOUND
echo Lancement ComfyUI depuis : %COMFY_PATH%
cd /d "%COMFY_PATH%"
python main.py --disable-smart-memory --normalvram --cpu-vae ^
    --use-pytorch-cross-attention --preview-method none --disable-auto-launch
pause
"""
    (INSTALL_ROOT / "LAUNCH_COMFYUI.bat").write_text(comfy_bat, encoding="utf-8")
    log.ok("LAUNCH_COMFYUI.bat")

    # ── INSTALL_MODELS.bat — BUG 2 FIXÉ : appel .bat via start ──
    models_bat = f"""@echo off
chcp 65001 >nul
title OverLord — Modeles
cd /d "{D}"

echo.
echo  Telechargement des dependances OverLord...
echo.

:: Verifier si le script de telechargement existe
if exist "download_dependencies.bat" (
    echo Lancement de download_dependencies.bat...
    call download_dependencies.bat
) else (
    echo Script download_dependencies.bat absent.
    echo Telechargement manuel requis.
)

echo.
echo  Modeles a telecharger manuellement sur civitai.com :
echo.
echo  1. NoobAI-XL (noobaiXLNSFWPony_epsilonPred10.safetensors)
echo     Destination : [ComfyUI]\\models\\checkpoints\\
echo.
echo  2. Apres telechargement, mets a jour le workflow :
echo     python update_checkpoint.py "noobaiXLNSFWPony_epsilonPred10.safetensors"
echo.
pause
"""
    (INSTALL_ROOT / "INSTALL_MODELS.bat").write_text(models_bat, encoding="utf-8")
    log.ok("INSTALL_MODELS.bat")

    return True


# ══════════════════════════════════════════════════════════════════════
# ÉTAPE 7 : RACCOURCI BUREAU
# ══════════════════════════════════════════════════════════════════════

def step_create_shortcut() -> bool:
    """BUG 3 FIXÉ : winreg protégé, pas de crash si non-Windows."""
    log.section("ÉTAPE 7 — Raccourci Bureau")

    if DRY_RUN:
        log.info("(simulation) créerait raccourci Bureau")
        return True

    try:
        desktop = Path(os.path.expanduser("~")) / "Desktop"
        if not desktop.exists():
            userprofile = os.environ.get("USERPROFILE", "")
            if userprofile:
                desktop = Path(userprofile) / "Desktop"

        if desktop.exists():
            shortcut = desktop / "OverLord Pipeline.bat"
            shortcut.write_text(
                f"@echo off\ncd /d \"{INSTALL_ROOT}\"\ncall START_OVERLORD.bat\n",
                encoding="utf-8"
            )
            log.ok(f"Raccourci Bureau : {shortcut}")
        else:
            log.warn("Bureau non trouvé — lance directement START_OVERLORD.bat")
    except Exception as e:
        log.warn(f"Raccourci non créé ({e}) — lance directement START_OVERLORD.bat")

    return True  # non bloquant


# ══════════════════════════════════════════════════════════════════════
# ÉTAPE 8 : VÉRIFICATION FINALE
# ══════════════════════════════════════════════════════════════════════

def step_final_check() -> bool:
    log.section("ÉTAPE 8 — Vérification finale")

    critical = [
        "launcher.py", "maestro.py", "neural_orchestrator.py",
        "agent_supervisor_v2.py", "storage_manager.py",
        "AGENTS/context_bus.py", "AGENTS/pipeline_constitution.py",
        "AGENTS/v130_world_model.py", "AGENTS/v130_emotion_engine.py",
        "AGENTS/v130_dashboard.py", "AGENTS/v130_agent_personality.py",
        "AGENTS/v140_thermal_protection.py",
        "config.json", "settings.json",
        "START_OVERLORD.bat", "LAUNCH_COMFYUI.bat",
    ]

    missing = []
    for cf in critical:
        p = INSTALL_ROOT / cf
        if DRY_RUN:
            log.info(f"(simulation) {cf}")
        elif p.exists():
            log.ok(cf)
        else:
            log.warn(f"Manquant : {cf}")
            missing.append(cf)

    if not DRY_RUN:
        total = sum(1 for _ in INSTALL_ROOT.rglob("*") if _.is_file())
        log.ok(f"Total : {total} fichiers dans {INSTALL_ROOT}")

    if missing:
        log.warn(f"{len(missing)} fichier(s) critique(s) absent(s) "
                  f"— l'installation peut être incomplète")
        log.warn("Cause probable : structure source différente de l'attendu")
        log.warn("Solution : relance install_overlord.py depuis le dossier PIPELINE PROJECT/")

    return len(missing) == 0


# ══════════════════════════════════════════════════════════════════════
# ENTRÉE PRINCIPALE
# ══════════════════════════════════════════════════════════════════════

def main() -> bool:
    log._write("=" * 60)
    log._write(f"  OverLord Pipeline v1.30 — Installation")
    log._write(f"  {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
    log._write(f"  Cible : {INSTALL_ROOT}")
    log._write(f"  Mode  : {'SIMULATION' if DRY_RUN else 'RÉEL'}")
    log._write("=" * 60)

    steps = [
        ("Prérequis",         step_check_prerequisites),
        ("Structure",         step_create_structure),
        ("Copie fichiers",    step_copy_files),
        ("Dépendances",       step_install_deps),
        ("Configuration",     step_create_config),
        ("Scripts lancement", step_create_launchers),
        ("Raccourci Bureau",  step_create_shortcut),
        ("Vérification",      step_final_check),
    ]

    results = {}
    for name, fn in steps:
        try:
            results[name] = fn()
        except Exception as e:
            log.err(f"Étape '{name}' : exception inattendue : {e}")
            results[name] = False

    log.section("RÉSUMÉ")
    all_ok = True
    for name, ok in results.items():
        log._write(f"  {'✓' if ok else '✗'}  {name}")
        if not ok:
            all_ok = False

    if all_ok:
        log._write("\n" + "═" * 60)
        log._write("  INSTALLATION RÉUSSIE !")
        log._write(f"  Lance : {INSTALL_ROOT}\\START_OVERLORD.bat")
        if not DRY_RUN:
            log._write(f"  ou double-clique sur 'OverLord Pipeline' sur le Bureau")
        log._write("═" * 60)
    else:
        log._write("\n⚠ Installation partielle.")
        log._write(f"  Consulte {LOG_FILE} pour les détails.")

    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
