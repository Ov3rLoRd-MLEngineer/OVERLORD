@echo off
chcp 65001 >nul
title OverLord — Installation des dépendances
cd /d "D:\OVERLORD"

echo ============================================================
echo    OverLord — Installation des dépendances et modèles
echo ============================================================
echo(

:MENU
echo Que voulez-vous installer ?
echo(
echo   [1] Dépendances Python essentielles
echo   [2] Dépendances recommandées (réseaux sociaux, audio...)
echo   [3] Dépendances V1.40 (vidéo, voix, thermique)
echo   [4] Tout installer (1+2+3)
echo   [5] Afficher les modèles à télécharger manuellement
echo   [6] Quitter
echo(
set /p CHOICE=Votre choix [1-6] : 

if "%CHOICE%"=="1" goto :ESSENTIAL
if "%CHOICE%"=="2" goto :RECOMMENDED
if "%CHOICE%"=="3" goto :V140
if "%CHOICE%"=="4" goto :ALL
if "%CHOICE%"=="5" goto :MODELS
if "%CHOICE%"=="6" exit
goto :MENU

:ESSENTIAL
echo(
echo [1/3] Installation des packages essentiels...
python -m pip install requests Pillow feedparser pytrends customtkinter flask cryptography trimesh psutil colorama python-dotenv --quiet
echo [OK] Packages essentiels installés.
goto :DONE

:RECOMMENDED
echo(
echo [2/3] Installation des packages recommandés...
python -m pip install tweepy google-auth google-auth-oauthlib google-api-python-client chromadb sentence-transformers pywin32 websocket-client opencv-python --quiet
python -m pip install nvidia-ml-py tbb --quiet
echo [OK] Packages recommandés installés.
goto :DONE

:V140
echo(
echo [3/3] Installation des packages V1.40...
python -m pip install imageio imageio-ffmpeg librosa ascii-magic discord.py --quiet
python -m pip install python-dotenv flask-limiter --quiet
echo [OK] Packages V1.40 installés.
goto :DONE

:ALL
echo(
echo Installation complète en cours (peut prendre 5-15 minutes)...
python -m pip install requests Pillow feedparser pytrends customtkinter flask cryptography trimesh psutil colorama python-dotenv tweepy google-auth google-auth-oauthlib google-api-python-client chromadb sentence-transformers pywin32 websocket-client opencv-python nvidia-ml-py tbb imageio imageio-ffmpeg librosa ascii-magic discord.py flask-limiter --quiet
echo [OK] Installation complète terminée.
goto :DONE

:MODELS
echo(
echo ============================================================
echo    MODÈLES À TÉLÉCHARGER MANUELLEMENT
echo ============================================================
echo(
echo  CHECKPOINT (obligatoire) :
echo  → Site  : https://civitai.com/models/833294
echo  → Fichier : noobaiXLNSFWPony_epsilonPred10.safetensors
echo  → Dossier : [ComfyUI]\models\checkpoints\
echo(
echo  VAE :
echo  → sdxl_vae.safetensors
echo  → Dossier : [ComfyUI]\models\vae\
echo(
echo  UPSCALER :
echo  → 4x-UltraSharp.pth
echo  → Dossier : [ComfyUI]\models\upscale_models\
echo(
echo  CONTROLNET (optionnel) :
echo  → controlnet-canny-sdxl-1.0.safetensors
echo  → Dossier : [ComfyUI]\models\controlnet\
echo(
echo  Après téléchargement, mets à jour le workflow :
echo  python update_checkpoint.py "noobaiXLNSFWPony_epsilonPred10.safetensors"
echo(
goto :DONE

:DONE
echo(
pause
goto :MENU
