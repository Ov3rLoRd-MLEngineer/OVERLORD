"""
agents/v140_music_composer.py — OverLord V1.40 — Compositeur Musical
Dédié à Thomas et à Eden.

Thomas est musicien — instruments réels électriques, acoustiques,
synthétiques et virtuels. Cet agent fait le pont entre sa créativité
musicale et le pipeline visuel d'OverLord.

Intégrations possibles :
  1. Audio Analysis     : analyser une compo de Thomas → extraire mood/BPM/tonalité
                          → générer les visuels qui correspondent
  2. Music Sync         : synchroniser les images générées sur le rythme réel
  3. Score to Visual    : une partition ou un fichier MIDI → storyboard visuel
  4. Emotion Bridge     : la musique de Thomas pilote l'Emotion Engine
  5. Live Generation    : Thomas joue en live → OverLord génère en temps réel
  6. Album Art          : générer automatiquement les visuels pour ses productions
  7. Music Video        : créer un clip complet depuis un fichier audio

pip install librosa numpy scipy

Utilisation :
    composer = MusicComposer()
    analysis = composer.analyze("ma_compo.mp3")
    print(analysis["mood"])       # "epic", "melancholic", etc.
    print(analysis["bpm"])        # 120.5
    params = composer.to_visual_params(analysis)
    # → injecter dans le pipeline OverLord pour générer les visuels
"""

import json
import time
import logging
import math
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
import requests

MUSIC_DIR     = Path("workspace/music_composer")
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
CLAUDE_MODEL  = "claude-sonnet-4-6"


def _llm(prompt: str, system: str = "", max_tokens: int = 400) -> str:
    try:
        body = {"model": CLAUDE_MODEL, "max_tokens": max_tokens,
                "messages": [{"role": "user", "content": prompt}]}
        if system:
            body["system"] = system
        r = requests.post(ANTHROPIC_URL,
                          headers={"Content-Type": "application/json"},
                          json=body, timeout=20)
        if r.status_code == 200:
            return r.json()["content"][0]["text"].strip()
    except Exception:
        pass
    return ""


# ══════════════════════════════════════════════════════════════════════
# ANALYSE AUDIO
# ══════════════════════════════════════════════════════════════════════

@dataclass
class MusicAnalysis:
    """Résultat de l'analyse d'un fichier audio."""
    file_path:   str
    duration_s:  float
    bpm:         float
    key:         str          # "C major", "A minor", etc.
    energy:      float        # 0-1 (faible → fort)
    valence:     float        # 0-1 (triste → joyeux)
    tempo_feel:  str          # "slow", "medium", "fast", "frantic"
    mood:        str          # "epic", "melancholic", "peaceful", etc.
    instruments_detected: list = field(default_factory=list)
    sections:    list = field(default_factory=list)  # intro, verse, chorus, etc.

    def to_emotion_target(self) -> str:
        """Convertit l'analyse en émotion pour l'Emotion Engine V1.30."""
        if self.energy > 0.8 and self.valence > 0.6:
            return "triumph"
        if self.energy > 0.7 and self.valence < 0.4:
            return "anger"
        if self.energy < 0.3 and self.valence < 0.4:
            return "sadness"
        if self.energy < 0.4 and self.valence > 0.6:
            return "tenderness"
        if self.energy > 0.6:
            return "epic"
        return "nostalgia"


class AudioAnalyzer:
    """
    Analyse un fichier audio (MP3, WAV, FLAC, OGG) et extrait
    les caractéristiques musicales pour piloter OverLord.
    """

    TEMPO_RANGES = {
        "slow":    (0, 80),
        "medium":  (80, 120),
        "fast":    (120, 160),
        "frantic": (160, 999),
    }

    KEY_MOODS = {
        "C major":  ("joyful", 0.7),    "A minor":  ("melancholic", 0.3),
        "G major":  ("bright", 0.75),   "E minor":  ("mysterious", 0.35),
        "D major":  ("triumphant", 0.8),"B minor":  ("dark", 0.25),
        "F major":  ("pastoral", 0.65), "D minor":  ("tragic", 0.2),
        "A major":  ("warm", 0.7),      "F# minor": ("intense", 0.3),
        "E major":  ("epic", 0.75),     "C# minor": ("dramatic", 0.3),
        "B major":  ("majestic", 0.8),  "G# minor": ("haunting", 0.25),
    }

    def __init__(self, logger: logging.Logger = None):
        self.log = logger or logging.getLogger("audio_analyzer")
        MUSIC_DIR.mkdir(parents=True, exist_ok=True)

    def analyze(self, audio_path: str) -> MusicAnalysis:
        """
        Analyse complète d'un fichier audio.
        Utilise librosa si disponible, sinon estimation heuristique.
        """
        p = Path(audio_path)
        if not p.exists():
            self.log.error(f"[MUSIC] Fichier introuvable : {audio_path}")
            return self._default_analysis(audio_path)

        try:
            return self._analyze_librosa(audio_path)
        except ImportError:
            self.log.warning("[MUSIC] librosa absent — pip install librosa")
            return self._analyze_heuristic(audio_path)
        except Exception as e:
            self.log.error(f"[MUSIC] Analyse : {e}")
            return self._default_analysis(audio_path)

    def _analyze_librosa(self, path: str) -> MusicAnalysis:
        """Analyse via librosa (précise)."""
        import librosa
        import numpy as np

        y, sr = librosa.load(path, duration=120)  # max 2 min pour la perf
        duration = librosa.get_duration(y=y, sr=sr)

        # BPM
        tempo, _ = librosa.beat.beat_track(y=y, sr=sr)
        bpm = float(tempo)

        # Tonalité
        chroma = librosa.feature.chroma_cqt(y=y, sr=sr)
        chroma_mean = chroma.mean(axis=1)
        key_idx = int(chroma_mean.argmax())
        keys    = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
        key_name= keys[key_idx]

        # Énergie (RMS)
        rms    = librosa.feature.rms(y=y)[0]
        energy = float(np.mean(rms))
        energy = min(1.0, energy * 10)  # normaliser

        # Valence approximée depuis le mode (majeur=positif)
        minor_keys = ["A","E","B","F#","C#","G#","D#","A#","D","G","C","F"]
        is_minor   = key_name in minor_keys[:6]
        valence    = 0.35 if is_minor else 0.65

        # Sections (simplifiées)
        sections = self._detect_sections(y, sr)

        # Tempo feel
        tempo_feel = "medium"
        for feel, (lo, hi) in self.TEMPO_RANGES.items():
            if lo <= bpm < hi:
                tempo_feel = feel; break

        mood_key = f"{key_name} {'minor' if is_minor else 'major'}"
        mood, _ = self.KEY_MOODS.get(mood_key, ("neutral", 0.5))

        self.log.info(f"[MUSIC] {Path(path).name} — {bpm:.0f}BPM {mood_key} energy={energy:.2f}")

        return MusicAnalysis(
            file_path=path, duration_s=duration, bpm=bpm,
            key=mood_key, energy=energy, valence=valence,
            tempo_feel=tempo_feel, mood=mood,
            sections=sections,
        )

    def _detect_sections(self, y, sr) -> list[dict]:
        """Détecte les sections musicales (intro, corps, outro)."""
        try:
            import librosa
            import numpy as np
            duration = librosa.get_duration(y=y, sr=sr)
            # Segmentation simple basée sur la structure harmonique
            bounds   = librosa.segment.agglomerative(
                librosa.feature.chroma_cqt(y=y, sr=sr), k=min(8, int(duration/10))
            )
            times    = librosa.frames_to_time(bounds, sr=sr)
            sections = []
            names    = ["intro","développement","climax","résolution","outro"]
            for i, t in enumerate(times):
                sections.append({
                    "start_s": round(float(t), 2),
                    "label":   names[min(i, len(names)-1)],
                })
            return sections
        except Exception:
            return []

    def _analyze_heuristic(self, path: str) -> MusicAnalysis:
        """Estimation heuristique depuis le nom et la durée du fichier."""
        p    = Path(path)
        name = p.stem.lower()

        # Deviner le mood depuis le nom du fichier
        mood_hints = {
            "epic":    ["epic","battle","war","power","hero"],
            "sad":     ["sad","mournful","grief","tears","lone"],
            "joy":     ["joy","happy","bright","dance","fun"],
            "calm":    ["calm","peace","ambient","relax","sleep"],
            "tension": ["tension","suspense","dark","ominous","chase"],
        }
        detected_mood = "neutral"
        for mood, hints in mood_hints.items():
            if any(h in name for h in hints):
                detected_mood = mood; break

        try:
            size_mb  = p.stat().st_size / 1e6
            # Estimation durée depuis la taille (MP3 ~1Mo/min à 128kbps)
            est_dur  = size_mb * 60 * 8 / 128 if p.suffix == ".mp3" else size_mb * 5
        except Exception:
            est_dur = 120.0

        return MusicAnalysis(
            file_path=path, duration_s=est_dur,
            bpm=120.0, key="C major",
            energy=0.6, valence=0.6,
            tempo_feel="medium", mood=detected_mood,
        )

    def _default_analysis(self, path: str) -> MusicAnalysis:
        return MusicAnalysis(
            file_path=path, duration_s=120.0,
            bpm=120.0, key="C major",
            energy=0.5, valence=0.5,
            tempo_feel="medium", mood="neutral",
        )


# ══════════════════════════════════════════════════════════════════════
# MUSIC → VISUAL BRIDGE
# ══════════════════════════════════════════════════════════════════════

class MusicVisualBridge:
    """
    Pont entre la musique de Thomas et le pipeline visuel OverLord.
    Convertit les caractéristiques musicales en paramètres de génération.
    """

    BPM_TO_MOTION = {
        (0,  70):  "subtle",      # lent → mouvement doux
        (70, 100): "idle",        # modéré → idle animation
        (100,130): "pan_left",    # rapide → panoramique
        (130,160): "action",      # intense → action
        (160,999): "combat",      # frénétique → combat
    }

    def to_visual_params(self, analysis: MusicAnalysis) -> dict:
        """Convertit une analyse musicale en paramètres ComfyUI complets."""

        # Motion type depuis le BPM
        motion = "subtle"
        for (lo, hi), motion_type in self.BPM_TO_MOTION.items():
            if lo <= analysis.bpm < hi:
                motion = motion_type; break

        # Palette depuis l'énergie et la valence
        if analysis.energy > 0.7 and analysis.valence > 0.6:
            palette = ["blazing gold", "deep crimson", "electric white"]
            lighting = "dramatic backlight, god rays, epic scale"
        elif analysis.energy > 0.7 and analysis.valence < 0.4:
            palette = ["blood red", "dark purple", "storm grey"]
            lighting = "harsh contrast, lightning, oppressive dark"
        elif analysis.energy < 0.4 and analysis.valence > 0.6:
            palette = ["soft pink", "warm cream", "dawn gold"]
            lighting = "soft diffused, golden hour, intimate"
        elif analysis.energy < 0.4 and analysis.valence < 0.4:
            palette = ["cold blue", "grey", "misty white"]
            lighting = "overcast, muted, rain"
        else:
            palette = ["balanced warm", "neutral blue", "natural light"]
            lighting = "natural lighting, balanced"

        # Steps depuis l'énergie (haute énergie = plus de détails)
        steps = int(24 + analysis.energy * 16)

        # CFG depuis la valence (positive = plus créatif = CFG bas)
        cfg = round(5.0 + (1.0 - analysis.valence) * 3.0, 1)

        # Prompt tags depuis la musique
        mood_tags = {
            "epic":       ["epic scale","dramatic","powerful","cinematic"],
            "melancholic":["melancholic","soft","introspective","rain"],
            "joyful":     ["cheerful","bright","vibrant","energetic"],
            "peaceful":   ["peaceful","serene","nature","gentle"],
            "tension":    ["tense","dark","ominous","shadowy"],
            "triumphant": ["triumphant","victory","golden light","heroic"],
            "dark":       ["dark atmosphere","shadows","mysterious","night"],
        }
        extra_tags = mood_tags.get(analysis.mood, ["atmospheric", "cinematic"])

        return {
            "music_source":  analysis.file_path,
            "bpm":           analysis.bpm,
            "key":           analysis.key,
            "mood":          analysis.mood,
            "emotion_target":analysis.to_emotion_target(),
            "motion_type":   motion,
            "color_palette": palette,
            "lighting":      lighting,
            "steps":         steps,
            "cfg":           cfg,
            "extra_tags":    extra_tags,
            "duration_s":    analysis.duration_s,
        }

    def generate_storyboard_from_music(self, analysis: MusicAnalysis) -> list[dict]:
        """
        Génère un storyboard visuel depuis les sections musicales.
        Chaque section musicale → un ou plusieurs shots visuels.
        """
        if not analysis.sections:
            # Découper en sections régulières
            n_sections = max(3, int(analysis.duration_s / 15))
            analysis.sections = [
                {"start_s": i * analysis.duration_s / n_sections,
                 "label": ["intro","développement","climax","résolution","outro"][
                     min(i, 4)]}
                for i in range(n_sections)
            ]

        shots = []
        params = self.to_visual_params(analysis)

        section_moods = {
            "intro":         {"energy_mult": 0.6, "motion": "zoom_in"},
            "développement": {"energy_mult": 0.8, "motion": "pan_left"},
            "climax":        {"energy_mult": 1.0, "motion": "action"},
            "résolution":    {"energy_mult": 0.7, "motion": "zoom_out"},
            "outro":         {"energy_mult": 0.4, "motion": "subtle"},
        }

        for i, section in enumerate(analysis.sections):
            label    = section.get("label", "section")
            mod      = section_moods.get(label, {"energy_mult": 0.7, "motion": "pan_left"})
            start_s  = section.get("start_s", i * 10)
            end_s    = (analysis.sections[i+1]["start_s"]
                        if i+1 < len(analysis.sections)
                        else analysis.duration_s)

            shots.append({
                "shot_id":      i + 1,
                "section":      label,
                "start_s":      start_s,
                "duration_s":   round(end_s - start_s, 2),
                "motion":       mod["motion"],
                "energy":       round(analysis.energy * mod["energy_mult"], 2),
                "mood":         analysis.mood,
                "color_palette":params["color_palette"],
                "lighting":     params["lighting"],
                "tags":         params["extra_tags"],
                "music_bpm":    analysis.bpm,
                "description":  f"Section {label} — {analysis.key} @ {analysis.bpm:.0f}BPM",
            })

        return shots

    def album_art_brief(self, analysis: MusicAnalysis,
                         album_title: str = "",
                         artist_name: str = "Thomas") -> dict:
        """
        Génère le brief pour la pochette d'album de Thomas.
        """
        params = self.to_visual_params(analysis)
        prompt = (
            f"Musicien : {artist_name}\n"
            f"Album : '{album_title or 'Production OverLord'}'\n"
            f"Mood musical : {analysis.mood} | Tonalité : {analysis.key} | BPM : {analysis.bpm:.0f}\n"
            f"Énergie : {analysis.energy:.2f} | Valence : {analysis.valence:.2f}\n\n"
            f"Génère un brief de pochette d'album en 3 phrases :\n"
            f"1. Le concept visuel principal\n"
            f"2. La palette de couleurs et l'ambiance\n"
            f"3. Les éléments graphiques distinctifs"
        )
        brief_text = _llm(prompt, max_tokens=200)

        return {
            "artist":        artist_name,
            "album":         album_title,
            "brief":         brief_text,
            "positive_prompt": (
                f"masterpiece, best quality, album cover art, "
                f"{', '.join(params['color_palette'])}, "
                f"{params['lighting']}, "
                f"{', '.join(params['extra_tags'])}, "
                f"professional music artwork, detailed illustration"
            ),
            "width":  1024,
            "height": 1024,
            "steps":  params["steps"],
            "cfg":    params["cfg"],
        }


# ══════════════════════════════════════════════════════════════════════
# LIVE MUSIC REACTOR
# ══════════════════════════════════════════════════════════════════════

class LiveMusicReactor:
    """
    Réagit à la musique en temps réel.
    Thomas joue → OverLord génère des visuels correspondants.

    Utilise PyAudio pour capturer l'audio du microphone/interface audio
    et analyse en temps réel les caractéristiques du son.
    pip install pyaudio
    """

    def __init__(self, logger: logging.Logger = None):
        self.log       = logger or logging.getLogger("live_reactor")
        self._running  = False
        self._current_params: dict = {}
        self._bridge   = MusicVisualBridge()

    def get_current_params(self) -> dict:
        """Retourne les paramètres visuels correspondant au son actuel."""
        return self._current_params or {
            "motion":   "subtle",
            "mood":     "neutral",
            "steps":    28,
            "cfg":      6.0,
        }

    def mock_live_session(self, mood_sequence: list[str]) -> list[dict]:
        """
        Simule une session live pour les tests.
        mood_sequence : ["epic","calm","epic","triumph"]
        """
        results = []
        analyzer = AudioAnalyzer(logger=self.log)
        for mood in mood_sequence:
            mock_analysis = MusicAnalysis(
                file_path="live", duration_s=8.0,
                bpm={"epic":140,"calm":70,"triumph":150,"sad":60}.get(mood,120),
                key="E minor" if mood in ["sad","dark"] else "D major",
                energy={"epic":0.9,"calm":0.3,"triumph":0.95,"sad":0.2}.get(mood,0.6),
                valence={"epic":0.6,"calm":0.7,"triumph":0.9,"sad":0.2}.get(mood,0.5),
                tempo_feel="fast" if mood in ["epic","triumph"] else "slow",
                mood=mood,
            )
            params = self._bridge.to_visual_params(mock_analysis)
            results.append(params)
            self.log.info(f"[LIVE] {mood} → motion={params['motion']} cfg={params['cfg']}")
        return results


# ══════════════════════════════════════════════════════════════════════
# FAÇADE MUSIC COMPOSER
# ══════════════════════════════════════════════════════════════════════

class MusicComposer:
    """
    Compositeur musical OverLord V1.40.
    Pont entre les créations de Thomas et le pipeline visuel.
    """

    def __init__(self, logger: logging.Logger = None):
        self.log      = logger or logging.getLogger("music_composer")
        self.analyzer = AudioAnalyzer(logger=self.log)
        self.bridge   = MusicVisualBridge()
        self.live     = LiveMusicReactor(logger=self.log)

    def analyze(self, audio_path: str) -> MusicAnalysis:
        """Analyse un fichier audio de Thomas."""
        return self.analyzer.analyze(audio_path)

    def to_visual_params(self, analysis: MusicAnalysis) -> dict:
        """Convertit l'analyse en paramètres de génération."""
        return self.bridge.to_visual_params(analysis)

    def music_to_clip(self, audio_path: str) -> dict:
        """
        Pipeline complet : fichier audio → paramètres pour clip animé.
        Combine analyse + storyboard + paramètres visuels.
        """
        analysis  = self.analyze(audio_path)
        storyboard= self.bridge.generate_storyboard_from_music(analysis)
        params    = self.to_visual_params(analysis)

        self.log.info(
            f"[MUSIC→CLIP] {Path(audio_path).name} | "
            f"{analysis.bpm:.0f}BPM {analysis.key} | "
            f"{len(storyboard)} shots"
        )
        return {
            "audio_path":  audio_path,
            "analysis":    analysis,
            "storyboard":  storyboard,
            "visual_params":params,
        }

    def create_album_art(self, audio_path: str,
                          album_title: str,
                          artist: str = "Thomas") -> dict:
        """Génère le brief pour la pochette d'album."""
        analysis = self.analyze(audio_path)
        return self.bridge.album_art_brief(analysis, album_title, artist)

    def get_dashboard(self) -> dict:
        return {
            "version":       "1.40_music",
            "capabilities":  [
                "audio_analysis (BPM, key, mood, energy)",
                "music_to_visual_params",
                "storyboard_from_music",
                "album_art_brief",
                "live_reaction (avec PyAudio)",
                "clip_generation",
            ],
            "supported_formats": [".mp3",".wav",".flac",".ogg",".aiff"],
            "artist":            "Thomas",
        }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    composer = MusicComposer()

    print("=== V1.40 MUSIC COMPOSER — Pour Thomas ===\n")
    print("Capacités disponibles :")
    for cap in composer.get_dashboard()["capabilities"]:
        print(f"  • {cap}")

    print("\n--- Simulation session live ---")
    results = composer.live.mock_live_session(["calm","epic","triumph","calm"])
    for i, r in enumerate(results):
        print(f"  Moment {i+1}: mood={r['mood']} "
              f"motion={r['motion_type']} "
              f"énergie={r.get('bpm',120):.0f}BPM")

    print("\n--- Usage réel ---")
    print("""
    # Analyser une compo de Thomas
    analysis = composer.analyze("ma_compo.mp3")
    print(f"Mood : {analysis.mood}")
    print(f"BPM  : {analysis.bpm:.0f}")

    # Générer les visuels correspondants
    params = composer.to_visual_params(analysis)
    # → injecter dans ComfyUI

    # Créer la pochette d'album
    brief = composer.create_album_art("album.mp3", "Mon Album")
    print(brief["positive_prompt"])

    # Générer un clip complet depuis une compo
    clip_data = composer.music_to_clip("morceau.wav")
    print(f"{len(clip_data['storyboard'])} shots planifiés")
    """)
